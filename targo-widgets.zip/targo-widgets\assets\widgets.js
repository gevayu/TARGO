/* Targo Widgets — header scroll-shrink + mobile hamburger */
(function () {
  'use strict';

  function initHeader(header) {
    if (!header || header.dataset.targoBound) return;
    header.dataset.targoBound = '1';

    var threshold = 24;
    function onScroll() {
      if (window.scrollY > threshold) header.classList.add('is-scrolled');
      else header.classList.remove('is-scrolled');
    }
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });

    var burger = header.querySelector('.targo-header-burger');
    if (burger) {
      burger.addEventListener('click', function () {
        var open = header.classList.toggle('menu-open');
        burger.setAttribute('aria-expanded', open ? 'true' : 'false');
        burger.setAttribute('aria-label', open ? 'סגור תפריט' : 'פתח תפריט');
      });
      // Close menu when a link is tapped
      header.querySelectorAll('.targo-header-nav a').forEach(function (a) {
        a.addEventListener('click', function () {
          header.classList.remove('menu-open');
          burger.setAttribute('aria-expanded', 'false');
          burger.setAttribute('aria-label', 'פתח תפריט');
        });
      });
    }
  }

  function boot() {
    document.querySelectorAll('.targo-header').forEach(initHeader);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }
})();
