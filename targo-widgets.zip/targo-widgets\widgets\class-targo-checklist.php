<?php
namespace Targo_Widgets;

if ( ! defined( 'ABSPATH' ) ) exit;

use Elementor\Controls_Manager;
use Elementor\Repeater;

/**
 * Vertical list of checkmark/dot items, single column.
 * Used inside the SC section "trust points" block.
 */
class Checklist extends Base_Widget {

    public function get_name() { return 'targo-checklist'; }
    public function get_title() { return __( 'Targo · Checklist', 'targo-widgets' ); }
    public function get_icon() { return 'eicon-bullet-list'; }
    public function get_keywords() { return array( 'targo', 'list', 'checkmarks', 'points' ); }

    protected function register_controls() {
        $this->start_controls_section( 'content_section', array(
            'label' => __( 'Items', 'targo-widgets' ),
            'tab'   => Controls_Manager::TAB_CONTENT,
        ) );

        $rep = new Repeater();
        $rep->add_control( 'item_text', array(
            'label'   => 'Item',
            'type'    => Controls_Manager::TEXTAREA,
            'rows'    => 2,
            'default' => 'נקודה',
        ) );

        $this->add_control( 'items', array(
            'label'   => 'Items',
            'type'    => Controls_Manager::REPEATER,
            'fields'  => $rep->get_controls(),
            'default' => array(
                array( 'item_text' => 'מוסמך ISO 9001, ניהול איכות בסטנדרט בינלאומי' ),
                array( 'item_text' => 'ספקים מאומתים במזרח אסיה, אירופה וארה״ב' ),
                array( 'item_text' => 'עמידה בדרישות FDA, CE ו-ISO 13485' ),
                array( 'item_text' => 'הזמנות סדרתיות שוטפות, אנחנו מבצעים, אתם לא נוגעים' ),
                array( 'item_text' => 'ניהול תפעול חודשי, Fractional COO לחברות ללא מנהל תפעול' ),
                array( 'item_text' => 'אתם מתרכזים במוצר, אנחנו מנהלים את הספק' ),
            ),
            'title_field' => '{{{ item_text }}}',
        ) );

        $this->add_control( 'icon_style', array(
            'label'   => 'Marker style',
            'type'    => Controls_Manager::SELECT,
            'options' => array(
                'check' => 'Blue circle + white checkmark',
                'dot'   => 'Dot',
            ),
            'default' => 'check',
        ) );

        $this->end_controls_section();

        $this->start_controls_section( 'style', array(
            'label' => 'Item text',
            'tab'   => Controls_Manager::TAB_STYLE,
        ) );
        $this->add_text_controls( 'item', array(
            'label'         => 'Item',
            'selector'      => '.targo-checklist-item',
            'default_color' => '#0A0A0A',
        ) );
        $this->end_controls_section();
    }

    protected function render() {
        $s = $this->get_settings_for_display();
        $items = $s['items'] ?? array();
        if ( empty( $items ) ) return;
        $style = $s['icon_style'] ?? 'check';

        echo '<ul class="targo-checklist targo-checklist--' . esc_attr( $style ) . '">';
        foreach ( $items as $it ) {
            echo '<li class="targo-checklist-item">' . esc_html( $it['item_text'] ) . '</li>';
        }
        echo '</ul>';
    }
}
