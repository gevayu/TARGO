<?php
namespace Targo_Widgets;

if ( ! defined( 'ABSPATH' ) ) exit;

use Elementor\Controls_Manager;
use Elementor\Repeater;

/**
 * Inline strip of N stats with a colored accent on the first item.
 * Used as the "hero stats" strip below the about hero.
 */
class Stats_Strip extends Base_Widget {

    public function get_name() { return 'targo-stats-strip'; }
    public function get_title() { return __( 'Targo · Stats Strip', 'targo-widgets' ); }
    public function get_icon() { return 'eicon-counter'; }
    public function get_keywords() { return array( 'targo', 'stats', 'numbers', 'kpi' ); }

    protected function register_controls() {
        $this->start_controls_section( 'content_section', array(
            'label' => __( 'Stats', 'targo-widgets' ),
            'tab'   => Controls_Manager::TAB_CONTENT,
        ) );

        $rep = new Repeater();
        $rep->add_control( 'stat_num', array(
            'label'   => 'Number',
            'type'    => Controls_Manager::TEXT,
            'default' => '25+',
        ) );
        $rep->add_control( 'stat_label', array(
            'label'   => 'Label',
            'type'    => Controls_Manager::TEXTAREA,
            'rows'    => 2,
            'default' => 'שנות ניסיון',
        ) );
        $rep->add_control( 'stat_accent', array(
            'label'   => 'Accent',
            'type'    => Controls_Manager::SELECT,
            'options' => array(
                'navy'   => 'Navy (default)',
                'orange' => 'Orange',
                'green'  => 'Green',
            ),
            'default' => 'navy',
        ) );

        $this->add_control( 'stats', array(
            'label'   => 'Stats',
            'type'    => Controls_Manager::REPEATER,
            'fields'  => $rep->get_controls(),
            'default' => array(
                array( 'stat_num' => '25+', 'stat_label' => 'שנות ניסיון בתעשייה',                            'stat_accent' => 'navy' ),
                array( 'stat_num' => '22%', 'stat_label' => 'חיסכון ממוצע בעלויות רכש',                       'stat_accent' => 'navy' ),
                array( 'stat_num' => '4',   'stat_label' => 'תעשיות ליבה: ביטחוני, רפואי, HiTech, תעשייה', 'stat_accent' => 'orange' ),
            ),
            'title_field' => '{{{ stat_num }}} · {{{ stat_label }}}',
        ) );

        $this->add_control( 'columns', array(
            'label'   => 'Columns',
            'type'    => Controls_Manager::SELECT,
            'options' => array( '2' => '2', '3' => '3', '4' => '4' ),
            'default' => '3',
        ) );

        $this->end_controls_section();
    }

    protected function render() {
        $s = $this->get_settings_for_display();
        $stats = $s['stats'] ?? array();
        if ( empty( $stats ) ) return;
        $cols = (int) ( $s['columns'] ?? 3 );

        echo '<div class="targo-stats-strip targo-stats-strip--cols-' . esc_attr( $cols ) . '">';
        foreach ( $stats as $st ) {
            $accent = $st['stat_accent'] ?? 'navy';
            echo '<div class="targo-stat targo-stat--' . esc_attr( $accent ) . '">';
            echo '<div class="targo-stat-num">' . esc_html( $st['stat_num'] ) . '</div>';
            echo '<div class="targo-stat-label">' . esc_html( $st['stat_label'] ) . '</div>';
            echo '</div>';
        }
        echo '</div>';
    }
}
