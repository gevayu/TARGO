<?php
namespace Targo_Widgets;

if ( ! defined( 'ABSPATH' ) ) exit;

use Elementor\Controls_Manager;
use Elementor\Repeater;

/**
 * Vertical timeline of career/role milestones.
 * Each item: years + role (heading) + company + description.
 * One can be marked "current" for visual emphasis.
 */
class Timeline extends Base_Widget {

    public function get_name() { return 'targo-timeline'; }
    public function get_title() { return __( 'Targo · Timeline', 'targo-widgets' ); }
    public function get_icon() { return 'eicon-time-line'; }
    public function get_keywords() { return array( 'targo', 'timeline', 'career', 'history' ); }

    protected function register_controls() {

        $this->start_controls_section( 'content_section', array(
            'label' => __( 'Items', 'targo-widgets' ),
            'tab'   => Controls_Manager::TAB_CONTENT,
        ) );

        $rep = new Repeater();
        $rep->add_control( 'years', array(
            'label'   => 'Years',
            'type'    => Controls_Manager::TEXT,
            'default' => '2020 — היום',
        ) );
        $rep->add_control( 'role', array(
            'label'   => 'Role',
            'type'    => Controls_Manager::TEXT,
            'default' => 'מייסד ומנכ"ל',
        ) );
        $rep->add_control( 'company', array(
            'label'   => 'Company',
            'type'    => Controls_Manager::TEXT,
            'default' => 'טרגו פתרונות',
        ) );
        $rep->add_control( 'badges', array(
            'label'   => 'Badges (one per line)',
            'type'    => Controls_Manager::TEXTAREA,
            'rows'    => 2,
            'default' => '',
            'description' => 'Small pills inside the meta line.',
        ) );
        $rep->add_control( 'desc', array(
            'label'   => 'Description',
            'type'    => Controls_Manager::TEXTAREA,
            'rows'    => 3,
            'default' => 'תיאור התפקיד.',
        ) );
        $rep->add_control( 'highlight', array(
            'label'   => 'Highlight (optional)',
            'type'    => Controls_Manager::TEXT,
            'default' => '',
            'description' => 'Single line of highlighted achievement.',
        ) );
        $rep->add_control( 'is_current', array(
            'label'        => 'Current role',
            'type'         => Controls_Manager::SWITCHER,
            'label_on'     => 'Yes',
            'label_off'    => 'No',
            'return_value' => 'yes',
            'default'      => '',
        ) );

        $this->add_control( 'items', array(
            'label'   => 'Items',
            'type'    => Controls_Manager::REPEATER,
            'fields'  => $rep->get_controls(),
            'default' => array(
                array( 'years' => '2020 — היום', 'role' => 'מייסד ומנכ"ל', 'company' => 'טרגו פתרונות', 'desc' => 'הקמת חברת ייעוץ והוצאה לפועל לתפעול ושרשרת אספקה.', 'is_current' => 'yes' ),
                array( 'years' => '2015 — 2020', 'role' => 'סמנכ"ל תפעול',  'company' => 'תאגיד ביטחוני', 'desc' => 'ניהול כל מערך התפעול.', 'is_current' => '' ),
            ),
            'title_field' => '{{{ years }}} · {{{ role }}}',
        ) );

        $this->add_control( 'role_h_tag', array(
            'label'   => 'Role heading tag',
            'type'    => Controls_Manager::SELECT,
            'options' => array( 'h2' => 'H2','h3' => 'H3','h4' => 'H4','h5' => 'H5','h6' => 'H6','div' => 'div' ),
            'default' => 'h3',
        ) );

        $this->end_controls_section();

        // STYLE: role
        $this->start_controls_section( 'style_role', array(
            'label' => 'Role',
            'tab'   => Controls_Manager::TAB_STYLE,
        ) );
        $this->add_text_controls( 'tl_role', array(
            'label'         => 'Role',
            'selector'      => '.targo-tl-role',
            'default_color' => '#0A083B',
        ) );
        $this->end_controls_section();

        // STYLE: company
        $this->start_controls_section( 'style_company', array(
            'label' => 'Company',
            'tab'   => Controls_Manager::TAB_STYLE,
        ) );
        $this->add_text_controls( 'tl_company', array(
            'label'         => 'Company',
            'selector'      => '.targo-tl-company',
            'default_color' => '#081F49',
        ) );
        $this->end_controls_section();

        // STYLE: years
        $this->start_controls_section( 'style_years', array(
            'label' => 'Years',
            'tab'   => Controls_Manager::TAB_STYLE,
        ) );
        $this->add_text_controls( 'tl_years', array(
            'label'         => 'Years',
            'selector'      => '.targo-tl-years',
            'default_color' => '#57586E',
        ) );
        $this->end_controls_section();
    }

    protected function render() {
        $s = $this->get_settings_for_display();
        $items = $s['items'] ?? array();
        if ( empty( $items ) ) return;

        $tag = $s['role_h_tag'] ?? 'h3';
        $allowed_tags = array( 'h1','h2','h3','h4','h5','h6','div' );
        if ( ! in_array( $tag, $allowed_tags, true ) ) $tag = 'h3';

        $widget_id = 'targo-timeline-' . esc_attr( $this->get_id() );
        echo '<ol class="targo-timeline" id="' . $widget_id . '">';
        foreach ( $items as $item ) {
            $current = ! empty( $item['is_current'] ) && $item['is_current'] === 'yes';
            $cls = 'targo-tl-item' . ( $current ? ' targo-tl-item--current targo-tl-item--in-view' : '' );
            echo '<li class="' . $cls . '">';
            echo '<div class="targo-tl-dot" aria-hidden="true"></div>';
            if ( ! empty( $item['years'] ) ) {
                echo '<div class="targo-tl-years">' . esc_html( $item['years'] ) . '</div>';
            }
            echo '<div class="targo-tl-card">';
            if ( ! empty( $item['role'] ) ) {
                printf( '<%1$s class="targo-tl-role">%2$s</%1$s>',
                    esc_attr( $tag ),
                    esc_html( $item['role'] )
                );
            }
            $has_company = ! empty( $item['company'] );
            $badges = ! empty( $item['badges'] )
                ? array_filter( array_map( 'trim', preg_split( '/\r?\n/', $item['badges'] ) ) )
                : array();
            if ( $has_company || ! empty( $badges ) ) {
                echo '<div class="targo-tl-meta">';
                if ( $has_company ) {
                    echo '<span class="targo-tl-company">' . esc_html( $item['company'] ) . '</span>';
                }
                foreach ( $badges as $b ) {
                    echo '<span class="targo-tl-badge">' . esc_html( $b ) . '</span>';
                }
                echo '</div>';
            }
            if ( ! empty( $item['desc'] ) ) {
                echo '<p class="targo-tl-desc">' . esc_html( $item['desc'] ) . '</p>';
            }
            if ( ! empty( $item['highlight'] ) ) {
                echo '<div class="targo-tl-highlight">' . esc_html( $item['highlight'] ) . '</div>';
            }
            echo '</div>'; // .targo-tl-card
            echo '</li>';
        }
        echo '</ol>';

        // Scroll-following dot: highlight whichever item is currently in viewport center
        ?>
        <script>
        (function(){
            var root = document.getElementById('<?php echo esc_js( $widget_id ); ?>');
            if (!root || typeof IntersectionObserver === 'undefined') return;
            var items = root.querySelectorAll('.targo-tl-item');
            if (!items.length) return;

            var observer = new IntersectionObserver(function(entries){
                entries.forEach(function(entry){
                    if (entry.isIntersecting) {
                        items.forEach(function(it){ it.classList.remove('targo-tl-item--in-view'); });
                        entry.target.classList.add('targo-tl-item--in-view');
                    }
                });
            }, { rootMargin: '-40% 0px -50% 0px', threshold: 0 });

            items.forEach(function(it){ observer.observe(it); });
        })();
        </script>
        <?php
    }
}
