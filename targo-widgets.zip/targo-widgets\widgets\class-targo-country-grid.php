<?php
namespace Targo_Widgets;

if ( ! defined( 'ABSPATH' ) ) exit;

use Elementor\Controls_Manager;
use Elementor\Repeater;

/**
 * Network grid: list of regions/countries with KPI numbers below.
 * Replaces emoji wordmarks with editorial typographic stack.
 */
class Country_Grid extends Base_Widget {

    public function get_name() { return 'targo-country-grid'; }
    public function get_title() { return __( 'Targo · Country / Network Grid', 'targo-widgets' ); }
    public function get_icon() { return 'eicon-global-settings'; }
    public function get_keywords() { return array( 'targo', 'country', 'network', 'global' ); }

    protected function register_controls() {

        $this->start_controls_section( 'content_section', array(
            'label' => __( 'Regions', 'targo-widgets' ),
            'tab'   => Controls_Manager::TAB_CONTENT,
        ) );

        $rep = new Repeater();
        $rep->add_control( 'region_en', array(
            'label'   => 'Region (LTR)',
            'type'    => Controls_Manager::TEXT,
            'default' => 'EAST ASIA',
        ) );
        $rep->add_control( 'region_he', array(
            'label'   => 'Region (Hebrew)',
            'type'    => Controls_Manager::TEXT,
            'default' => 'מזרח אסיה',
        ) );
        $rep->add_control( 'region_country', array(
            'label'   => 'Country line',
            'type'    => Controls_Manager::TEXT,
            'default' => 'סין · טאיוואן',
        ) );
        $rep->add_control( 'region_specs', array(
            'label'       => 'Specs (one per line)',
            'type'        => Controls_Manager::TEXTAREA,
            'rows'        => 4,
            'default'     => "CNC · מתכת · פלסטיק\nPCB · אלקטרוניקה · היטק\nנפחים גדולים · מחיר תחרותי",
            'description' => 'One spec per line.',
        ) );
        $rep->add_control( 'region_badge', array(
            'label'   => 'Badge text (optional)',
            'type'    => Controls_Manager::TEXT,
            'default' => 'מחיר · נפח · אמינות',
        ) );

        $this->add_control( 'regions', array(
            'label'   => 'Regions',
            'type'    => Controls_Manager::REPEATER,
            'fields'  => $rep->get_controls(),
            'default' => array(
                array( 'region_en' => 'EAST ASIA', 'region_he' => 'מזרח אסיה', 'region_country' => 'סין · טאיוואן',          'region_specs' => "CNC · מתכת · פלסטיק · 3D Print\nPCB · אלקטרוניקה · היטק\nנפחים גדולים · מחיר תחרותי\nאמינות גבוהה · דיוק", 'region_badge' => 'מחיר · נפח · אמינות' ),
                array( 'region_en' => 'EUROPE',    'region_he' => 'אירופה',    'region_country' => 'רומניה · הולנד · יוון', 'region_specs' => "Made in Europe · תעודות CE\nמתכת · פלסטיק · אופטיקה\nדיוק גבוה · סטנדרטים אירופאים\nכבילה · קרוב לישראל", 'region_badge' => 'CE · ISO · דיוק' ),
                array( 'region_en' => 'AMERICAS',  'region_he' => 'ארה״ב',      'region_country' => 'USA',                  'region_specs' => "CNC דיוק גבוה\nציפויים מיוחדים\nעמידה בדרישות FDA ו-DoD\nסטנדרטים ביטחוניים ורפואיים", 'region_badge' => 'FDA · DoD · ציפויים' ),
            ),
            'title_field' => '{{{ region_en }}}',
        ) );

        $this->add_control( 'columns', array(
            'label'   => 'Columns',
            'type'    => Controls_Manager::SELECT,
            'options' => array( '2' => '2', '3' => '3', '4' => '4' ),
            'default' => '3',
        ) );

        // KPI strip
        $kpi_rep = new Repeater();
        $kpi_rep->add_control( 'kpi_num', array(
            'label'   => 'Number',
            'type'    => Controls_Manager::TEXT,
            'default' => '20+',
        ) );
        $kpi_rep->add_control( 'kpi_label', array(
            'label'   => 'Label',
            'type'    => Controls_Manager::TEXT,
            'default' => 'מדינות',
        ) );
        $this->add_control( 'kpis', array(
            'label'   => 'KPI strip',
            'type'    => Controls_Manager::REPEATER,
            'fields'  => $kpi_rep->get_controls(),
            'default' => array(
                array( 'kpi_num' => '20+', 'kpi_label' => 'מדינות' ),
                array( 'kpi_num' => '500+','kpi_label' => 'ספקים מאומתים' ),
                array( 'kpi_num' => '24/7','kpi_label' => 'זמינות' ),
                array( 'kpi_num' => 'GLOBAL','kpi_label' => 'פריסה' ),
            ),
            'title_field' => '{{{ kpi_num }}} · {{{ kpi_label }}}',
        ) );

        $this->add_control( 'footer_cta_text', array(
            'label'   => 'Footer CTA text',
            'type'    => Controls_Manager::TEXT,
            'default' => 'רוצים לדעת מאיזו מדינה כדאי לייצר? ←',
        ) );
        $this->add_control( 'footer_cta_url', array(
            'label'   => 'Footer CTA URL',
            'type'    => Controls_Manager::URL,
            'default' => array( 'url' => 'https://wa.link/huf1g6' ),
        ) );

        $this->end_controls_section();
    }

    protected function render() {
        $s = $this->get_settings_for_display();
        $regions = $s['regions'] ?? array();
        $kpis    = $s['kpis'] ?? array();
        $cols    = (int) ( $s['columns'] ?? 3 );

        echo '<div class="targo-net">';

        if ( ! empty( $regions ) ) {
            echo '<div class="targo-net-grid targo-net-grid--cols-' . esc_attr( $cols ) . '">';
            foreach ( $regions as $r ) {
                echo '<div class="targo-net-card">';
                echo '<div class="targo-net-wordmark">';
                echo '<span class="targo-net-region">' . esc_html( $r['region_en'] ) . '</span>';
                echo '<span class="targo-net-region-sub">' . esc_html( $r['region_he'] ) . '</span>';
                echo '</div>';
                if ( ! empty( $r['region_country'] ) ) {
                    echo '<div class="targo-net-country">' . esc_html( $r['region_country'] ) . '</div>';
                }
                if ( ! empty( $r['region_specs'] ) ) {
                    $specs = array_map( 'trim', preg_split( '/\r?\n/', $r['region_specs'] ) );
                    echo '<div class="targo-net-specs">';
                    foreach ( $specs as $spec ) {
                        if ( $spec === '' ) continue;
                        echo '<div class="targo-net-spec">' . esc_html( $spec ) . '</div>';
                    }
                    echo '</div>';
                }
                if ( ! empty( $r['region_badge'] ) ) {
                    echo '<span class="targo-net-badge">' . esc_html( $r['region_badge'] ) . '</span>';
                }
                echo '</div>';
            }
            echo '</div>';
        }

        $cta_text = $s['footer_cta_text'] ?? '';
        $cta_url  = ! empty( $s['footer_cta_url']['url'] ) ? esc_url( $s['footer_cta_url']['url'] ) : '#';
        if ( ! empty( $kpis ) || $cta_text !== '' ) {
            echo '<div class="targo-net-footer">';
            if ( ! empty( $kpis ) ) {
                echo '<div class="targo-net-stats">';
                foreach ( $kpis as $k ) {
                    echo '<div class="targo-net-stat">';
                    echo '<div class="targo-net-stat-num">' . esc_html( $k['kpi_num'] ) . '</div>';
                    echo '<div class="targo-net-stat-label">' . esc_html( $k['kpi_label'] ) . '</div>';
                    echo '</div>';
                }
                echo '</div>';
            }
            if ( $cta_text !== '' ) {
                echo '<a class="targo-net-footer-cta" href="' . $cta_url . '">' . esc_html( $cta_text ) . '</a>';
            }
            echo '</div>';
        }

        echo '</div>';
    }
}
