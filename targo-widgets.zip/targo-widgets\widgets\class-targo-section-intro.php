<?php
namespace Targo_Widgets;

if ( ! defined( 'ABSPATH' ) ) exit;

use Elementor\Controls_Manager;

class Section_Intro extends Base_Widget {

    public function get_name() { return 'targo-section-intro'; }
    public function get_title() { return __( 'Targo · Section Intro', 'targo-widgets' ); }
    public function get_icon() { return 'eicon-heading'; }
    public function get_keywords() { return array( 'targo', 'intro', 'heading', 'eyebrow' ); }

    protected function register_controls() {

        $this->start_controls_section( 'content_section', array(
            'label' => __( 'Content', 'targo-widgets' ),
            'tab'   => Controls_Manager::TAB_CONTENT,
        ) );

        $this->add_control( 'eyebrow_text', array(
            'label'   => 'Eyebrow text',
            'type'    => Controls_Manager::TEXT,
            'default' => 'תעשיות שאנחנו מובילים',
        ) );

        $this->add_heading_controls( 'h2', array(
            'label'        => 'Heading',
            'default_text' => 'תעשיות שאנחנו <span class="hl">מובילים</span>',
            'default_tag'  => 'h2',
            'selector'     => '.targo-section-h2',
        ) );

        $this->add_control( 'lead_text', array(
            'label'   => 'Lead paragraph',
            'type'    => Controls_Manager::TEXTAREA,
            'rows'    => 4,
            'default' => 'בכל תעשייה — תפעול חכם, רכש אסטרטגי, ושרשרת אספקה שמסונכרנת עם המטרות העסקיות שלכם.',
        ) );

        $this->add_control( 'align', array(
            'label'   => 'Alignment',
            'type'    => Controls_Manager::CHOOSE,
            'options' => array(
                'right'  => array( 'title' => 'Right', 'icon' => 'eicon-text-align-right' ),
                'center' => array( 'title' => 'Center','icon' => 'eicon-text-align-center' ),
                'left'   => array( 'title' => 'Left',  'icon' => 'eicon-text-align-left' ),
            ),
            'default'   => 'right',
            'selectors' => array(
                '{{WRAPPER}} .targo-section-intro' => 'text-align: {{VALUE}};',
            ),
        ) );

        $this->end_controls_section();

        // STYLE: lead
        $this->start_controls_section( 'style_lead', array(
            'label' => 'Lead text',
            'tab'   => Controls_Manager::TAB_STYLE,
        ) );
        $this->add_text_controls( 'lead', array(
            'label'         => 'Lead',
            'selector'      => '.targo-section-lead',
            'default_color' => '#4A4540',
        ) );
        $this->end_controls_section();

        // STYLE: eyebrow
        $this->start_controls_section( 'style_eyebrow', array(
            'label' => 'Eyebrow',
            'tab'   => Controls_Manager::TAB_STYLE,
        ) );
        $this->add_text_controls( 'eyebrow', array(
            'label'         => 'Eyebrow',
            'selector'      => '.targo-eyebrow',
            'default_color' => '#B8843A',
        ) );
        $this->end_controls_section();
    }

    protected function render() {
        $s = $this->get_settings_for_display();
        $eyebrow = esc_html( $s['eyebrow_text'] ?? '' );
        $lead_raw = $s['lead_text'] ?? '';

        echo '<div class="targo-section-intro">';
        if ( $eyebrow ) {
            echo '<div class="targo-eyebrow">' . $eyebrow . '</div>';
        }
        $this->render_heading( 'h2', $s, 'targo-section-h2' );
        if ( $lead_raw !== '' ) {
            $allowed = array(
                'strong' => array(), 'em' => array(), 'br' => array(),
                'span'   => array( 'class' => array() ),
                'a'      => array( 'href' => array(), 'target' => array(), 'rel' => array() ),
            );
            // Convert blank lines to paragraph breaks
            $paragraphs = preg_split( '/\r?\n\r?\n/', trim( $lead_raw ) );
            foreach ( $paragraphs as $p ) {
                $p = nl2br( $p );
                echo '<p class="targo-section-lead">' . wp_kses( $p, $allowed ) . '</p>';
            }
        }
        echo '</div>';
    }
}
