<?php
namespace Targo_Widgets;

if ( ! defined( 'ABSPATH' ) ) exit;

use Elementor\Controls_Manager;
use Elementor\Repeater;

class Hero extends Base_Widget {

    public function get_name() { return 'targo-hero'; }
    public function get_title() { return __( 'Targo · Hero', 'targo-widgets' ); }
    public function get_icon() { return 'eicon-banner'; }
    public function get_keywords() { return array( 'targo', 'hero', 'header', 'landing' ); }

    protected function register_controls() {

        // ───── CONTENT ─────
        $this->start_controls_section( 'content_section', array(
            'label' => __( 'Content', 'targo-widgets' ),
            'tab'   => Controls_Manager::TAB_CONTENT,
        ) );

        $this->add_control( 'eyebrow_text', array(
            'label'   => 'Eyebrow text',
            'type'    => Controls_Manager::TEXT,
            'default' => 'תפעול · רכש · שרשרת אספקה · AI',
        ) );

        $this->add_heading_controls( 'h1', array(
            'label'        => 'Main heading',
            'default_text' => 'חיסכון אמיתי. שליטה מלאה. <span class="hl">שרשרת אספקה שעובדת.</span>',
            'default_tag'  => 'h1',
            'selector'     => '.targo-hero-h1',
        ) );

        $this->add_control( 'lead_text', array(
            'label'      => 'Lead paragraph',
            'type'       => Controls_Manager::WYSIWYG,
            'default'    => '<p>לא ייעוץ, ביצוע. מתחילים בפרויקט ממוקד, מוכיחים ערך, וממשיכים לניהול שוטף. <strong>הלקוחות שלנו מתחילים בפרויקט אחד, ונשארים.</strong></p>',
        ) );

        $this->add_text_controls( 'lead', array(
            'label' => 'Lead',
            'selector' => '.targo-hero-lead',
            'default_color' => '#57586E',
        ) );

        // Industry chips repeater
        $rep = new Repeater();
        $rep->add_control( 'chip_text', array(
            'label' => 'Chip',
            'type'  => Controls_Manager::TEXT,
            'default' => 'תעשייה',
        ) );
        $this->add_control( 'chips', array(
            'label'        => 'Industry chips',
            'type'         => Controls_Manager::REPEATER,
            'fields'       => $rep->get_controls(),
            'default'      => array(
                array( 'chip_text' => 'ביטחון' ),
                array( 'chip_text' => 'מד-טק' ),
                array( 'chip_text' => 'היטק' ),
                array( 'chip_text' => 'תעשייה' ),
            ),
            'title_field' => '{{{ chip_text }}}',
        ) );

        // Buttons
        $this->add_control( 'btn1_text', array(
            'label'   => 'Primary button text',
            'type'    => Controls_Manager::TEXT,
            'default' => 'מתחילים בפרויקט ←',
        ) );
        $this->add_control( 'btn1_url', array(
            'label'   => 'Primary button URL',
            'type'    => Controls_Manager::URL,
            'default' => array( 'url' => 'https://wa.link/huf1g6' ),
        ) );
        $this->add_control( 'btn2_text', array(
            'label'   => 'Secondary button text',
            'type'    => Controls_Manager::TEXT,
            'default' => 'מה אנחנו עושים',
        ) );
        $this->add_control( 'btn2_url', array(
            'label'   => 'Secondary button URL',
            'type'    => Controls_Manager::URL,
            'default' => array( 'url' => '#services' ),
        ) );

        // Image
        $this->add_control( 'image', array(
            'label'   => 'Hero image',
            'type'    => Controls_Manager::MEDIA,
            'default' => array(
                'url' => 'https://targosolutions.com/wp-content/uploads/2025/12/top-view-smart-business-people-joining-gathering-wooden-gear-symposium-1024x576.jpg',
            ),
        ) );
        $this->add_control( 'image_alt', array(
            'label'   => 'Image alt',
            'type'    => Controls_Manager::TEXT,
            'default' => 'צוות מנהלים',
        ) );

        $this->add_control( 'image_aspect', array(
            'label'   => 'Image aspect ratio',
            'type'    => Controls_Manager::SELECT,
            'options' => array(
                '4/3' => 'Landscape 4:3 (default)',
                '3/4' => 'Portrait 3:4 (founder photo)',
                '1/1' => 'Square 1:1',
                '16/9' => 'Wide 16:9',
            ),
            'default' => '4/3',
        ) );

        $this->add_control( 'photo_tag_name', array(
            'label'   => 'Photo tag — name (optional)',
            'type'    => Controls_Manager::TEXT,
            'default' => '',
            'description' => 'When set, an overlay caption appears at the bottom of the image (e.g. founder name).',
        ) );

        $this->add_control( 'photo_tag_role', array(
            'label'   => 'Photo tag — role (optional)',
            'type'    => Controls_Manager::TEXT,
            'default' => '',
        ) );

        $this->end_controls_section();

        // ───── STYLE: typography for chips ─────
        $this->start_controls_section( 'style_chip', array(
            'label' => 'Chips style',
            'tab'   => Controls_Manager::TAB_STYLE,
        ) );
        $this->add_text_controls( 'chip', array(
            'label' => 'Chip',
            'selector' => '.targo-hero-chip',
            'default_color' => '#0A083B',
        ) );
        $this->end_controls_section();

        // ───── STYLE: layout ─────
        $this->start_controls_section( 'style_layout', array(
            'label' => 'Layout',
            'tab'   => Controls_Manager::TAB_STYLE,
        ) );
        $this->add_responsive_control( 'text_width', array(
            'label' => 'Text column width (%)',
            'type'  => Controls_Manager::SLIDER,
            'range' => array( '%' => array( 'min' => 30, 'max' => 80 ) ),
            'default' => array( 'unit' => '%', 'size' => 55 ),
            'selectors' => array(
                '{{WRAPPER}} .targo-hero-text' => 'flex-basis: {{SIZE}}{{UNIT}};',
            ),
        ) );
        $this->add_responsive_control( 'image_width', array(
            'label' => 'Image column width (%)',
            'type'  => Controls_Manager::SLIDER,
            'range' => array( '%' => array( 'min' => 20, 'max' => 70 ) ),
            'default' => array( 'unit' => '%', 'size' => 40 ),
            'selectors' => array(
                '{{WRAPPER}} .targo-hero-image' => 'flex-basis: {{SIZE}}{{UNIT}};',
            ),
        ) );
        $this->add_responsive_control( 'gap', array(
            'label' => 'Gap between text and image',
            'type'  => Controls_Manager::SLIDER,
            'range' => array( 'rem' => array( 'min' => 0, 'max' => 8 ) ),
            'default' => array( 'unit' => 'rem', 'size' => 4 ),
            'selectors' => array(
                '{{WRAPPER}} .targo-hero-grid' => 'gap: {{SIZE}}{{UNIT}};',
            ),
        ) );
        $this->add_control( 'reverse', array(
            'label' => 'Image position',
            'type'  => Controls_Manager::SELECT,
            'options' => array(
                'left'  => 'Left of text',
                'right' => 'Right of text',
            ),
            'default' => 'left',
            'description' => 'In RTL, "left" means image appears at LTR-end (visually on the left).',
        ) );
        $this->end_controls_section();
    }

    protected function render() {
        $s = $this->get_settings_for_display();

        $eyebrow = esc_html( $s['eyebrow_text'] ?? '' );
        $lead    = $s['lead_text'] ?? '';

        $btn1_text = esc_html( $s['btn1_text'] );
        $btn1_url  = ! empty( $s['btn1_url']['url'] ) ? esc_url( $s['btn1_url']['url'] ) : '#';
        $btn2_text = esc_html( $s['btn2_text'] );
        $btn2_url  = ! empty( $s['btn2_url']['url'] ) ? esc_url( $s['btn2_url']['url'] ) : '#';

        $img_url = $s['image']['url'] ?? '';
        $img_alt = esc_attr( $s['image_alt'] ?? '' );

        $reverse = ( $s['reverse'] ?? 'left' ) === 'right' ? ' targo-hero-grid--reverse' : '';

        echo '<section class="targo-hero-section">';
        echo '<div class="targo-hero-grid' . $reverse . '">';

        echo '<div class="targo-hero-text">';
        if ( $eyebrow ) {
            echo '<div class="targo-eyebrow">' . $eyebrow . '</div>';
        }
        $this->render_heading( 'h1', $s, 'targo-hero-h1' );
        if ( $lead ) {
            echo '<div class="targo-hero-lead">' . wp_kses_post( $lead ) . '</div>';
        }
        if ( ! empty( $s['chips'] ) ) {
            echo '<div class="targo-hero-chips">';
            foreach ( $s['chips'] as $chip ) {
                echo '<span class="targo-hero-chip">' . esc_html( $chip['chip_text'] ) . '</span>';
            }
            echo '</div>';
        }
        echo '<div class="targo-hero-cta">';
        if ( $btn1_text ) {
            echo '<a class="targo-btn targo-btn-primary" href="' . $btn1_url . '">' . $btn1_text . '</a>';
        }
        if ( $btn2_text ) {
            echo '<a class="targo-btn targo-btn-ghost" href="' . $btn2_url . '">' . $btn2_text . '</a>';
        }
        echo '</div>';
        echo '</div>'; // .targo-hero-text

        if ( $img_url ) {
            $aspect = $s['image_aspect'] ?? '4/3';
            $aspect_class = 'targo-hero-image--' . str_replace( '/', 'x', $aspect );
            echo '<div class="targo-hero-image ' . esc_attr( $aspect_class ) . '">';
            echo '<div class="targo-hero-image-frame">';
            echo '<img src="' . esc_url( $img_url ) . '" alt="' . $img_alt . '" style="aspect-ratio:' . esc_attr( $aspect ) . ';" />';
            $tag_name = trim( $s['photo_tag_name'] ?? '' );
            $tag_role = trim( $s['photo_tag_role'] ?? '' );
            if ( $tag_name !== '' || $tag_role !== '' ) {
                echo '<div class="targo-hero-photo-tag">';
                if ( $tag_name !== '' ) echo '<span class="targo-hero-photo-tag-name">' . esc_html( $tag_name ) . '</span>';
                if ( $tag_role !== '' ) echo '<span class="targo-hero-photo-tag-role">' . esc_html( $tag_role ) . '</span>';
                echo '</div>';
            }
            echo '</div>';
            echo '</div>';
        }

        echo '</div>';
        echo '</section>';
    }
}
