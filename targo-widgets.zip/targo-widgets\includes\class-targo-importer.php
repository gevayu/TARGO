<?php
namespace Targo_Widgets;

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Admin tools page for importing the Targo home + about page templates
 * shipped inside this plugin.
 */
class Importer {

    const NONCE_ACTION = 'targo_import_pages';

    public static function init() {
        add_action( 'admin_menu', array( __CLASS__, 'register_menu' ) );
        add_action( 'admin_post_targo_import_pages', array( __CLASS__, 'handle_import' ) );
    }

    public static function register_menu() {
        add_menu_page(
            'Targo Solutions',
            'Targo Pages',
            'manage_options',
            'targo-pages',
            array( __CLASS__, 'render_page' ),
            'dashicons-admin-site-alt3',
            58
        );
    }

    public static function render_page() {
        if ( ! current_user_can( 'manage_options' ) ) return;

        $home   = self::find_page( 'home', 'עמוד ראשי' );
        $about  = self::find_page( 'about', 'אודות' );

        $notice = isset( $_GET['imported'] ) ? sanitize_text_field( $_GET['imported'] ) : '';
        ?>
        <div class="wrap">
            <h1>Targo Pages — ייבוא תבניות</h1>
            <?php if ( $notice === '1' ) : ?>
                <div class="notice notice-success"><p>הייבוא הושלם בהצלחה.</p></div>
            <?php elseif ( $notice === 'err' ) : ?>
                <div class="notice notice-error"><p>הייבוא נכשל. בדקו ש-Elementor פעיל וקבצי התבנית קיימים.</p></div>
            <?php endif; ?>

            <p>התוסף מגיע עם תבניות מוכנות לעמוד הבית ועמוד אודות. לחיצה על "ייבא" תיצור את הדפים (אם לא קיימים), תטען את התוכן, ותגדיר את עמוד הבית כדף הבית של האתר.</p>

            <table class="widefat striped" style="max-width:760px;margin-top:1rem">
                <thead>
                    <tr><th>עמוד</th><th>סטטוס נוכחי</th><th>קובץ תבנית</th></tr>
                </thead>
                <tbody>
                    <tr>
                        <td><strong>בית</strong></td>
                        <td><?php echo $home ? 'קיים (ID ' . (int) $home->ID . ')' : '<em>טרם נוצר</em>'; ?></td>
                        <td><?php echo file_exists( self::tpl_path( 'home' ) ) ? '✓ targo-home.json' : '<span style="color:#a00">חסר</span>'; ?></td>
                    </tr>
                    <tr>
                        <td><strong>אודות</strong></td>
                        <td><?php echo $about ? 'קיים (ID ' . (int) $about->ID . ')' : '<em>טרם נוצר</em>'; ?></td>
                        <td><?php echo file_exists( self::tpl_path( 'about' ) ) ? '✓ targo-about.json' : '<span style="color:#a00">חסר</span>'; ?></td>
                    </tr>
                </tbody>
            </table>

            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin-top:1.5rem">
                <input type="hidden" name="action" value="targo_import_pages" />
                <?php wp_nonce_field( self::NONCE_ACTION ); ?>
                <p>
                    <label><input type="checkbox" name="overwrite" value="1" /> לדרוס תוכן קיים אם יש</label>
                </p>
                <p>
                    <label><input type="checkbox" name="set_front" value="1" checked /> להגדיר את "בית" כעמוד הבית של האתר</label>
                </p>
                <p><button type="submit" class="button button-primary button-large">ייבא דפים</button></p>
            </form>
        </div>
        <?php
    }

    public static function handle_import() {
        if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Forbidden' );
        check_admin_referer( self::NONCE_ACTION );

        $overwrite = ! empty( $_POST['overwrite'] );
        $set_front = ! empty( $_POST['set_front'] );

        $home_data  = self::load_template( 'home' );
        $about_data = self::load_template( 'about' );

        if ( $home_data === null || $about_data === null ) {
            wp_safe_redirect( add_query_arg( 'imported', 'err', admin_url( 'admin.php?page=targo-pages' ) ) );
            exit;
        }

        $home_id  = self::ensure_page( 'home', 'בית', $home_data, $overwrite );
        $about_id = self::ensure_page( 'about', 'אודות', $about_data, $overwrite );

        if ( $home_id && $set_front ) {
            update_option( 'show_on_front', 'page' );
            update_option( 'page_on_front', $home_id );
        }

        // Flush Elementor caches
        self::flush_elementor_caches();

        wp_safe_redirect( add_query_arg( 'imported', '1', admin_url( 'admin.php?page=targo-pages' ) ) );
        exit;
    }

    protected static function tpl_path( $slug ) {
        return TARGO_WIDGETS_DIR . '/templates/targo-' . $slug . '.json';
    }

    protected static function load_template( $slug ) {
        $f = self::tpl_path( $slug );
        if ( ! file_exists( $f ) ) return null;
        $raw = file_get_contents( $f );
        $data = json_decode( $raw, true );
        return is_array( $data ) ? $data : null;
    }

    protected static function find_page( $slug, $title_fallback = '' ) {
        $p = get_page_by_path( $slug );
        if ( $p ) return $p;
        if ( $title_fallback ) {
            $q = new \WP_Query( array(
                'post_type' => 'page',
                'title' => $title_fallback,
                'posts_per_page' => 1,
                'no_found_rows' => true,
            ) );
            if ( ! empty( $q->posts ) ) return $q->posts[0];
        }
        return null;
    }

    protected static function ensure_page( $slug, $title, $elementor_data, $overwrite = false ) {
        $existing = self::find_page( $slug, $title );

        if ( $existing && ! $overwrite ) {
            // Page exists — only fill if its elementor data is empty
            $current = get_post_meta( $existing->ID, '_elementor_data', true );
            if ( ! empty( $current ) ) return (int) $existing->ID;
        }

        if ( $existing ) {
            $page_id = (int) $existing->ID;
            wp_update_post( array(
                'ID'           => $page_id,
                'post_title'   => $title,
                'post_status'  => 'publish',
            ) );
        } else {
            $page_id = wp_insert_post( array(
                'post_type'    => 'page',
                'post_status'  => 'publish',
                'post_title'   => $title,
                'post_name'    => $slug,
                'post_content' => '',
            ) );
            if ( is_wp_error( $page_id ) || ! $page_id ) return 0;
        }

        update_post_meta( $page_id, '_elementor_edit_mode', 'builder' );
        update_post_meta( $page_id, '_elementor_template_type', 'wp-page' );
        update_post_meta( $page_id, '_elementor_data', wp_slash( wp_json_encode( $elementor_data ) ) );
        update_post_meta( $page_id, '_elementor_version', defined( 'ELEMENTOR_VERSION' ) ? ELEMENTOR_VERSION : '4.0.0' );
        update_post_meta( $page_id, '_wp_page_template', 'default' );

        // Hide native title
        $page_settings = get_post_meta( $page_id, '_elementor_page_settings', true );
        if ( ! is_array( $page_settings ) ) $page_settings = array();
        $page_settings['hide_title'] = 'yes';
        update_post_meta( $page_id, '_elementor_page_settings', $page_settings );

        delete_post_meta( $page_id, '_elementor_css' );
        delete_post_meta( $page_id, '_elementor_element_cache' );

        return $page_id;
    }

    protected static function flush_elementor_caches() {
        global $wpdb;
        if ( isset( $wpdb ) ) {
            $wpdb->query( "DELETE FROM {$wpdb->postmeta} WHERE meta_key = '_elementor_element_cache'" );
        }
        delete_option( 'elementor_atomic_cache_validity__base' );
        delete_option( 'elementor_atomic_cache_validity__local' );
        delete_option( 'elementor_atomic_cache_validity__global' );

        $css_dir = WP_CONTENT_DIR . '/uploads/elementor/css/';
        if ( is_dir( $css_dir ) ) {
            foreach ( glob( $css_dir . 'post-*.css' ) ?: array() as $f ) @unlink( $f );
        }
    }
}
