<?php
namespace Targo_Widgets;

if ( ! defined( 'ABSPATH' ) ) exit;

use Elementor\Controls_Manager;
use Elementor\Repeater;

/**
 * Generic 3- or 4-column card grid.
 * Each card has: number/icon, heading (configurable tag), description.
 * Used for: How-it-works, Services, Principles, ISO sections.
 */
class Card_Grid extends Base_Widget {

    public function get_name() { return 'targo-card-grid'; }
    public function get_title() { return __( 'Targo · Card Grid', 'targo-widgets' ); }
    public function get_icon() { return 'eicon-posts-grid'; }
    public function get_keywords() { return array( 'targo', 'card', 'grid', 'features', 'services' ); }

    protected function register_controls() {

        $this->start_controls_section( 'content_section', array(
            'label' => __( 'Cards', 'targo-widgets' ),
            'tab'   => Controls_Manager::TAB_CONTENT,
        ) );

        $rep = new Repeater();
        $rep->add_control( 'card_num', array(
            'label'   => 'Number / icon char',
            'type'    => Controls_Manager::TEXT,
            'default' => '01',
        ) );
        $rep->add_control( 'card_title', array(
            'label'   => 'Title',
            'type'    => Controls_Manager::TEXT,
            'default' => 'כותרת',
        ) );
        $rep->add_control( 'card_desc', array(
            'label'   => 'Description',
            'type'    => Controls_Manager::TEXTAREA,
            'rows'    => 3,
            'default' => 'תיאור הכרטיס.',
        ) );
        $rep->add_control( 'card_meta', array(
            'label'       => 'Meta line (optional)',
            'type'        => Controls_Manager::TEXT,
            'default'     => '',
            'description' => 'Small line under description (e.g. duration, tags).',
        ) );
        $rep->add_control( 'card_badge', array(
            'label'       => 'Top-corner badge (optional)',
            'type'        => Controls_Manager::TEXT,
            'default'     => '',
            'description' => 'Pill in the corner — e.g. "AI Powered".',
        ) );
        $rep->add_control( 'card_points', array(
            'label'       => 'Bullet points (one per line, optional)',
            'type'        => Controls_Manager::TEXTAREA,
            'rows'        => 4,
            'default'     => '',
            'description' => 'Inner list. One point per line.',
        ) );

        $this->add_control( 'cards', array(
            'label'   => 'Cards',
            'type'    => Controls_Manager::REPEATER,
            'fields'  => $rep->get_controls(),
            'default' => array(
                array( 'card_num' => '01', 'card_title' => 'אבחון', 'card_desc' => 'נשב יחד, נבין את התמונה המלאה — מה עובד, מה לא.', 'card_meta' => '1-2 שבועות' ),
                array( 'card_num' => '02', 'card_title' => 'פרויקט', 'card_desc' => 'מתחילים בפרויקט מוגדר עם תוצאה מדידה.', 'card_meta' => '4-12 שבועות' ),
                array( 'card_num' => '03', 'card_title' => 'ניהול שוטף', 'card_desc' => 'עוברים לניהול שוטף.', 'card_meta' => 'שיתוף פעולה ארוך טווח' ),
            ),
            'title_field' => '{{{ card_num }}} · {{{ card_title }}}',
        ) );

        $this->add_control( 'columns', array(
            'label'   => 'Columns',
            'type'    => Controls_Manager::SELECT,
            'options' => array( '2' => '2', '3' => '3', '4' => '4' ),
            'default' => '3',
        ) );

        $this->add_control( 'card_h_tag', array(
            'label'   => 'Card heading tag',
            'type'    => Controls_Manager::SELECT,
            'options' => array(
                'h2' => 'H2','h3' => 'H3','h4' => 'H4','h5' => 'H5','h6' => 'H6','div' => 'div',
            ),
            'default' => 'h3',
        ) );

        $this->add_control( 'card_style', array(
            'label'   => 'Card style',
            'type'    => Controls_Manager::SELECT,
            'options' => array(
                'light'  => 'Light (white card)',
                'dark'   => 'Dark (navy card)',
                'flat'   => 'Flat (no background)',
                'tracks' => 'Tracks (label on top + blue accent)',
            ),
            'default' => 'light',
        ) );

        $this->end_controls_section();

        // STYLE: title
        $this->start_controls_section( 'style_title', array(
            'label' => 'Card title',
            'tab'   => Controls_Manager::TAB_STYLE,
        ) );
        $this->add_text_controls( 'card_title', array(
            'label'         => 'Title',
            'selector'      => '.targo-card-title',
            'default_color' => '#0A0A0A',
        ) );
        $this->end_controls_section();

        // STYLE: description
        $this->start_controls_section( 'style_desc', array(
            'label' => 'Card description',
            'tab'   => Controls_Manager::TAB_STYLE,
        ) );
        $this->add_text_controls( 'card_desc', array(
            'label'         => 'Description',
            'selector'      => '.targo-card-desc',
            'default_color' => '#4A4540',
        ) );
        $this->end_controls_section();

        // STYLE: number
        $this->start_controls_section( 'style_num', array(
            'label' => 'Card number',
            'tab'   => Controls_Manager::TAB_STYLE,
        ) );
        $this->add_text_controls( 'card_num', array(
            'label'         => 'Number',
            'selector'      => '.targo-card-num',
            'default_color' => '#B8843A',
        ) );
        $this->end_controls_section();
    }

    protected function render() {
        $s = $this->get_settings_for_display();
        $cards = $s['cards'] ?? array();
        if ( empty( $cards ) ) return;

        $cols = (int) ( $s['columns'] ?? 3 );
        $tag  = $s['card_h_tag'] ?? 'h3';
        $allowed_tags = array( 'h1','h2','h3','h4','h5','h6','div' );
        if ( ! in_array( $tag, $allowed_tags, true ) ) $tag = 'h3';
        $style = $s['card_style'] ?? 'light';

        echo '<div class="targo-card-grid targo-card-grid--cols-' . esc_attr( $cols ) . ' targo-card-grid--' . esc_attr( $style ) . '">';
        foreach ( $cards as $card ) {
            echo '<div class="targo-card">';
            if ( ! empty( $card['card_badge'] ) ) {
                echo '<div class="targo-card-badge">' . esc_html( $card['card_badge'] ) . '</div>';
            }
            if ( ! empty( $card['card_num'] ) ) {
                echo '<div class="targo-card-num">' . esc_html( $card['card_num'] ) . '</div>';
            }
            if ( ! empty( $card['card_title'] ) ) {
                printf( '<%1$s class="targo-card-title">%2$s</%1$s>',
                    esc_attr( $tag ),
                    esc_html( $card['card_title'] )
                );
            }
            if ( ! empty( $card['card_desc'] ) ) {
                echo '<p class="targo-card-desc">' . esc_html( $card['card_desc'] ) . '</p>';
            }
            if ( ! empty( $card['card_points'] ) ) {
                $points = array_map( 'trim', preg_split( '/\r?\n/', $card['card_points'] ) );
                echo '<ul class="targo-card-points">';
                foreach ( $points as $p ) {
                    if ( $p === '' ) continue;
                    echo '<li>' . esc_html( $p ) . '</li>';
                }
                echo '</ul>';
            }
            if ( ! empty( $card['card_meta'] ) ) {
                echo '<div class="targo-card-meta">' . esc_html( $card['card_meta'] ) . '</div>';
            }
            echo '</div>';
        }
        echo '</div>';
    }
}
