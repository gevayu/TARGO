<?php
namespace Targo_Widgets;

if ( ! defined( 'ABSPATH' ) ) exit;

use Elementor\Controls_Manager;
use Elementor\Repeater;

class Pain_Tabs extends Base_Widget {

    public function get_name() { return 'targo-pain-tabs'; }
    public function get_title() { return __( 'Targo · Industries / Pain Tabs', 'targo-widgets' ); }
    public function get_icon() { return 'eicon-tabs'; }
    public function get_keywords() { return array( 'targo', 'tabs', 'pain', 'industries' ); }

    protected function register_controls() {

        // ───── CONTENT ─────
        $this->start_controls_section( 'content_section', array(
            'label' => __( 'Tabs', 'targo-widgets' ),
            'tab'   => Controls_Manager::TAB_CONTENT,
        ) );

        // Pain item repeater (used inside each tab)
        $pain_rep = new Repeater();
        $pain_rep->add_control( 'pain_num', array(
            'label'   => 'Number',
            'type'    => Controls_Manager::TEXT,
            'default' => '1',
        ) );
        $pain_rep->add_control( 'pain_title', array(
            'label'   => 'Title',
            'type'    => Controls_Manager::TEXT,
            'default' => 'בעיה',
        ) );
        $pain_rep->add_control( 'pain_desc', array(
            'label'   => 'Description',
            'type'    => Controls_Manager::TEXTAREA,
            'rows'    => 2,
            'default' => 'תיאור הכאב.',
        ) );

        // Stats repeater (inside profile card)
        $stat_rep = new Repeater();
        $stat_rep->add_control( 'stat_num', array(
            'label'   => 'Number',
            'type'    => Controls_Manager::TEXT,
            'default' => '15+',
        ) );
        $stat_rep->add_control( 'stat_label', array(
            'label'   => 'Label',
            'type'    => Controls_Manager::TEXT,
            'default' => 'שנות ניסיון',
        ) );

        // Main tabs repeater
        $tab_rep = new Repeater();
        $tab_rep->add_control( 'tab_label', array(
            'label'   => 'Tab label',
            'type'    => Controls_Manager::TEXT,
            'default' => 'תעשייה',
        ) );
        $tab_rep->add_control( 'tab_badge', array(
            'label'   => 'Tab badge (optional)',
            'type'    => Controls_Manager::TEXT,
            'default' => '',
            'description' => 'Optional small pill before the tab label (e.g. "מתחילים", "צומחים").',
        ) );
        $tab_rep->add_control( 'tab_badge_color', array(
            'label'   => 'Badge color',
            'type'    => Controls_Manager::SELECT,
            'options' => array(
                'startup' => 'Green (startup)',
                'growth'  => 'Blue (growth)',
                'mature'  => 'Orange (mature)',
                'neutral' => 'Neutral',
            ),
            'default' => 'neutral',
            'condition' => array( 'tab_badge!' => '' ),
        ) );
        $tab_rep->add_control( 'profile_tag', array(
            'label'   => 'Profile tag (eyebrow)',
            'type'    => Controls_Manager::TEXT,
            'default' => 'התעשייה הזו',
        ) );
        $tab_rep->add_control( 'profile_title', array(
            'label'   => 'Profile title',
            'type'    => Controls_Manager::TEXTAREA,
            'rows'    => 2,
            'default' => 'מה הבעיות הקריטיות',
        ) );
        $tab_rep->add_control( 'profile_desc', array(
            'label'   => 'Profile description',
            'type'    => Controls_Manager::TEXTAREA,
            'rows'    => 3,
            'default' => 'תיאור התעשייה.',
        ) );
        $tab_rep->add_control( 'stats', array(
            'label'   => 'Stats',
            'type'    => Controls_Manager::REPEATER,
            'fields'  => $stat_rep->get_controls(),
            'default' => array(
                array( 'stat_num' => '15+', 'stat_label' => 'שנות ניסיון' ),
                array( 'stat_num' => '50+', 'stat_label' => 'פרויקטים' ),
            ),
            'title_field' => '{{{ stat_num }}} · {{{ stat_label }}}',
        ) );
        $tab_rep->add_control( 'pains', array(
            'label'   => 'Pain points',
            'type'    => Controls_Manager::REPEATER,
            'fields'  => $pain_rep->get_controls(),
            'default' => array(
                array( 'pain_num' => '1', 'pain_title' => 'בעיה ראשונה', 'pain_desc' => 'תיאור.' ),
                array( 'pain_num' => '2', 'pain_title' => 'בעיה שנייה',  'pain_desc' => 'תיאור.' ),
            ),
            'title_field' => '{{{ pain_num }}}. {{{ pain_title }}}',
        ) );
        $tab_rep->add_control( 'cta_text', array(
            'label'   => 'CTA text',
            'type'    => Controls_Manager::TEXT,
            'default' => '<strong>נשמע מוכר?</strong> בואו נתחיל בפרויקט ממוקד.',
        ) );
        $tab_rep->add_control( 'cta_btn_text', array(
            'label'   => 'CTA button text',
            'type'    => Controls_Manager::TEXT,
            'default' => 'דברו איתנו ←',
        ) );
        $tab_rep->add_control( 'cta_btn_url', array(
            'label'   => 'CTA button URL',
            'type'    => Controls_Manager::URL,
            'default' => array( 'url' => 'https://wa.link/huf1g6' ),
        ) );

        $this->add_control( 'tabs', array(
            'label'   => 'Tabs',
            'type'    => Controls_Manager::REPEATER,
            'fields'  => $tab_rep->get_controls(),
            'default' => array(
                array(
                    'tab_label'     => 'ביטחון',
                    'profile_tag'   => 'תעשיית הביטחון',
                    'profile_title' => 'הזמנים קצרים, הסטנדרטים <em>לא מתפשרים</em>',
                    'profile_desc'  => 'תקני AS9100, NADCAP, ITAR, EAR. כל פריט שעובר את הגבול דורש ניירת מדויקת.',
                ),
                array(
                    'tab_label'     => 'מד-טק',
                    'profile_tag'   => 'תעשיית המד-טק',
                    'profile_title' => 'איכות חיי אדם <em>לא נסבלת</em> פשרות',
                    'profile_desc'  => 'ISO 13485, FDA, MDR. כל רכיב חייב מקור מאומת ותיעוד מלא.',
                ),
                array(
                    'tab_label'     => 'היטק',
                    'profile_tag'   => 'תעשיית ההיטק',
                    'profile_title' => 'מהירות ההמצאה <em>גוברת</em> על הכל',
                    'profile_desc'  => 'NPI מהיר, פרויקטים שמתחילים עם דרישות חצי-מוגדרות.',
                ),
                array(
                    'tab_label'     => 'תעשייה',
                    'profile_tag'   => 'תעשייה כבדה',
                    'profile_title' => 'יצור הוא מסע, <em>לא ספרינט</em>',
                    'profile_desc'  => 'תכנון רב-שנתי, MOQs גבוהים, רכש בכמויות.',
                ),
            ),
            'title_field' => '{{{ tab_label }}}',
        ) );

        $this->end_controls_section();

        // STYLE: tab buttons
        $this->start_controls_section( 'style_tab_buttons', array(
            'label' => 'Tab buttons',
            'tab'   => Controls_Manager::TAB_STYLE,
        ) );
        $this->add_text_controls( 'tabbtn', array(
            'label'         => 'Tab',
            'selector'      => '.targo-tab-btn',
            'default_color' => '#57586E',
        ) );
        $this->end_controls_section();

        // STYLE: profile heading
        $this->start_controls_section( 'style_profile_h', array(
            'label' => 'Profile heading',
            'tab'   => Controls_Manager::TAB_STYLE,
        ) );
        $this->add_heading_controls( 'profile_h', array(
            'label'         => 'Profile heading',
            'default_text'  => '',
            'default_tag'   => 'h3',
            'selector'      => '.targo-pain-profile-title',
            'default_color' => '#FFFFFF',
        ) );
        $this->end_controls_section();
    }

    protected function render() {
        $s = $this->get_settings_for_display();
        $tabs = $s['tabs'] ?? array();
        if ( empty( $tabs ) ) return;

        $widget_id = 'targo-pain-tabs-' . esc_attr( $this->get_id() );
        $tag = $s['profile_h_tag'] ?? 'h3';
        $allowed_tags = array( 'h1','h2','h3','h4','h5','h6','div' );
        if ( ! in_array( $tag, $allowed_tags, true ) ) $tag = 'h3';

        echo '<div class="targo-pain-tabs" id="' . $widget_id . '">';

        // Tab buttons
        echo '<div class="targo-pain-tabs-nav">';
        foreach ( $tabs as $i => $tab ) {
            $active = $i === 0 ? ' is-active' : '';
            $badge = trim( $tab['tab_badge'] ?? '' );
            $badge_color = $tab['tab_badge_color'] ?? 'neutral';
            echo '<button type="button" class="targo-tab-btn' . $active . '" data-target="' . $i . '">';
            if ( $badge !== '' ) {
                echo '<span class="targo-pain-badge targo-pain-badge--' . esc_attr( $badge_color ) . '">' . esc_html( $badge ) . '</span> ';
            }
            echo esc_html( $tab['tab_label'] );
            echo '</button>';
        }
        echo '</div>';

        // Tab panels
        foreach ( $tabs as $i => $tab ) {
            $active = $i === 0 ? ' is-active' : '';
            echo '<div class="targo-pain-panel' . $active . '" data-panel="' . $i . '">';

            echo '<div class="targo-pain-panel-grid">';

            // Profile card (left)
            echo '<div class="targo-pain-profile">';
            if ( ! empty( $tab['profile_tag'] ) ) {
                echo '<div class="targo-pain-profile-tag">' . esc_html( $tab['profile_tag'] ) . '</div>';
            }
            $title_html = wp_kses( $tab['profile_title'] ?? '', array(
                'em'   => array(),
                'span' => array( 'class' => array() ),
                'strong' => array(),
            ) );
            printf( '<%1$s class="targo-pain-profile-title">%2$s</%1$s>', esc_attr( $tag ), $title_html );

            if ( ! empty( $tab['profile_desc'] ) ) {
                echo '<p class="targo-pain-profile-desc">' . esc_html( $tab['profile_desc'] ) . '</p>';
            }

            if ( ! empty( $tab['stats'] ) ) {
                echo '<div class="targo-pain-stats">';
                foreach ( $tab['stats'] as $stat ) {
                    echo '<div class="targo-pain-stat">';
                    echo '<div class="targo-pain-stat-num">' . esc_html( $stat['stat_num'] ) . '</div>';
                    echo '<div class="targo-pain-stat-label">' . esc_html( $stat['stat_label'] ) . '</div>';
                    echo '</div>';
                }
                echo '</div>';
            }
            echo '</div>'; // .targo-pain-profile

            // Pain list (right)
            echo '<div class="targo-pain-list">';
            if ( ! empty( $tab['pains'] ) ) {
                foreach ( $tab['pains'] as $pain ) {
                    echo '<div class="targo-pain-item">';
                    echo '<div class="targo-pain-num">' . esc_html( $pain['pain_num'] ) . '</div>';
                    echo '<div class="targo-pain-txt">';
                    echo '<h4>' . esc_html( $pain['pain_title'] ) . '</h4>';
                    echo '<p>' . esc_html( $pain['pain_desc'] ) . '</p>';
                    echo '</div>';
                    echo '</div>';
                }
            }
            echo '</div>'; // .targo-pain-list

            echo '</div>'; // .targo-pain-panel-grid

            // CTA row
            if ( ! empty( $tab['cta_text'] ) || ! empty( $tab['cta_btn_text'] ) ) {
                echo '<div class="targo-pain-cta">';
                if ( ! empty( $tab['cta_text'] ) ) {
                    echo '<p>' . wp_kses( $tab['cta_text'], array( 'strong' => array(), 'em' => array() ) ) . '</p>';
                }
                if ( ! empty( $tab['cta_btn_text'] ) ) {
                    $url = ! empty( $tab['cta_btn_url']['url'] ) ? esc_url( $tab['cta_btn_url']['url'] ) : '#';
                    echo '<a class="targo-pain-btn" href="' . $url . '">' . esc_html( $tab['cta_btn_text'] ) . '</a>';
                }
                echo '</div>';
            }

            echo '</div>'; // .targo-pain-panel
        }

        echo '</div>'; // .targo-pain-tabs

        // Inline JS for tab switching (per-instance, no jQuery, scoped)
        ?>
        <script>
        (function(){
            var root = document.getElementById('<?php echo esc_js( $widget_id ); ?>');
            if (!root) return;
            var btns = root.querySelectorAll('.targo-tab-btn');
            var panels = root.querySelectorAll('.targo-pain-panel');
            btns.forEach(function(btn){
                btn.addEventListener('click', function(){
                    var t = btn.getAttribute('data-target');
                    btns.forEach(function(b){ b.classList.remove('is-active'); });
                    panels.forEach(function(p){ p.classList.remove('is-active'); });
                    btn.classList.add('is-active');
                    var panel = root.querySelector('.targo-pain-panel[data-panel="' + t + '"]');
                    if (panel) panel.classList.add('is-active');
                });
            });
        })();
        </script>
        <?php
    }
}
