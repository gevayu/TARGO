<?php
/**
 * Plugin Name: Targo Solutions Widgets
 * Description: Custom Elementor widgets tailored to Targo Solutions design system. Every text, image and color is editable in Elementor's UI; each heading lets you pick H1/H2/H3/H4 and full typography overrides.
 * Version: 1.2.4
 * Author: Targo Solutions
 * Requires Plugins: elementor
 * Elementor tested up to: 4.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'TARGO_WIDGETS_FILE', __FILE__ );
define( 'TARGO_WIDGETS_DIR', __DIR__ );

/**
 * Register a "Targo" widget category in the Elementor editor.
 */
add_action( 'elementor/elements/categories_registered', function( $elements_manager ) {
    $elements_manager->add_category(
        'targo',
        array(
            'title' => __( 'Targo Solutions', 'targo-widgets' ),
            'icon'  => 'fa fa-star',
        )
    );
} );

/**
 * Register all custom widgets when Elementor loads.
 */
add_action( 'elementor/widgets/register', function( $widgets_manager ) {
    require_once TARGO_WIDGETS_DIR . '/widgets/class-targo-base-widget.php';
    require_once TARGO_WIDGETS_DIR . '/widgets/class-targo-hero.php';
    require_once TARGO_WIDGETS_DIR . '/widgets/class-targo-section-intro.php';
    require_once TARGO_WIDGETS_DIR . '/widgets/class-targo-pain-tabs.php';
    require_once TARGO_WIDGETS_DIR . '/widgets/class-targo-card-grid.php';
    require_once TARGO_WIDGETS_DIR . '/widgets/class-targo-country-grid.php';
    require_once TARGO_WIDGETS_DIR . '/widgets/class-targo-pull-quote.php';
    require_once TARGO_WIDGETS_DIR . '/widgets/class-targo-iso-card.php';
    require_once TARGO_WIDGETS_DIR . '/widgets/class-targo-timeline.php';
    require_once TARGO_WIDGETS_DIR . '/widgets/class-targo-cta-band.php';
    require_once TARGO_WIDGETS_DIR . '/widgets/class-targo-header.php';
    require_once TARGO_WIDGETS_DIR . '/widgets/class-targo-footer.php';
    require_once TARGO_WIDGETS_DIR . '/widgets/class-targo-checklist.php';
    require_once TARGO_WIDGETS_DIR . '/widgets/class-targo-stats-strip.php';

    $widgets_manager->register( new \Targo_Widgets\Hero() );
    $widgets_manager->register( new \Targo_Widgets\Section_Intro() );
    $widgets_manager->register( new \Targo_Widgets\Pain_Tabs() );
    $widgets_manager->register( new \Targo_Widgets\Card_Grid() );
    $widgets_manager->register( new \Targo_Widgets\Country_Grid() );
    $widgets_manager->register( new \Targo_Widgets\Pull_Quote() );
    $widgets_manager->register( new \Targo_Widgets\Iso_Card() );
    $widgets_manager->register( new \Targo_Widgets\Timeline() );
    $widgets_manager->register( new \Targo_Widgets\Cta_Band() );
    $widgets_manager->register( new \Targo_Widgets\Header() );
    $widgets_manager->register( new \Targo_Widgets\Footer() );
    $widgets_manager->register( new \Targo_Widgets\Checklist() );
    $widgets_manager->register( new \Targo_Widgets\Stats_Strip() );
} );

/**
 * Admin importer for the bundled home + about page templates.
 */
if ( is_admin() ) {
    require_once TARGO_WIDGETS_DIR . '/includes/class-targo-importer.php';
    \Targo_Widgets\Importer::init();
}

/**
 * Enqueue widget styles + Noto Sans Hebrew on frontend.
 */
add_action( 'wp_enqueue_scripts', function() {
    wp_enqueue_style(
        'targo-noto-hebrew',
        'https://fonts.googleapis.com/css2?family=Noto+Sans+Hebrew:wght@200;300;400;500;600;700;800&display=swap',
        array(),
        null
    );
    wp_enqueue_style(
        'targo-widgets',
        plugins_url( 'assets/widgets.css', TARGO_WIDGETS_FILE ),
        array( 'targo-noto-hebrew' ),
        '1.2.4'
    );
} );

// Also load fonts in the Elementor editor preview
add_action( 'elementor/editor/wp_head', function() {
    echo '<link rel="preconnect" href="https://fonts.googleapis.com">';
    echo '<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>';
    echo '<link href="https://fonts.googleapis.com/css2?family=Noto+Sans+Hebrew:wght@200;300;400;500;600;700;800&display=swap" rel="stylesheet">';
} );
