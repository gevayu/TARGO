<?php
namespace Targo_Widgets;

if ( ! defined( 'ABSPATH' ) ) exit;

use Elementor\Controls_Manager;
use Elementor\Repeater;

/**
 * ISO certification card: badge + heading + bullet list.
 */
class Iso_Card extends Base_Widget {

    public function get_name() { return 'targo-iso-card'; }
    public function get_title() { return __( 'Targo · ISO / Certification Card', 'targo-widgets' ); }
    public function get_icon() { return 'eicon-medal' ; }
    public function get_keywords() { return array( 'targo', 'iso', 'certification', 'badge' ); }

    protected function register_controls() {

        $this->start_controls_section( 'content_section', array(
            'label' => __( 'Content', 'targo-widgets' ),
            'tab'   => Controls_Manager::TAB_CONTENT,
        ) );

        $this->add_control( 'badge_image', array(
            'label'   => 'Badge image',
            'type'    => Controls_Manager::MEDIA,
            'default' => array(),
        ) );

        $this->add_control( 'badge_label', array(
            'label'   => 'Badge label (eyebrow)',
            'type'    => Controls_Manager::TEXT,
            'default' => 'הסמכה רשמית',
        ) );

        $this->add_heading_controls( 'h', array(
            'label'         => 'Heading',
            'default_text'  => 'מוסמכים <span class="hl">ISO 9001</span>',
            'default_tag'   => 'h3',
            'selector'      => '.targo-iso-h',
        ) );

        $this->add_control( 'lead', array(
            'label'   => 'Lead paragraph',
            'type'    => Controls_Manager::TEXTAREA,
            'rows'    => 3,
            'default' => 'מערכת ניהול איכות בינלאומית, מבוקרת חיצונית.',
        ) );

        $rep = new Repeater();
        $rep->add_control( 'point_text', array(
            'label'   => 'Point',
            'type'    => Controls_Manager::TEXT,
            'default' => 'נקודה',
        ) );
        $this->add_control( 'points', array(
            'label'   => 'Points',
            'type'    => Controls_Manager::REPEATER,
            'fields'  => $rep->get_controls(),
            'default' => array(
                array( 'point_text' => 'תהליכי עבודה מתועדים' ),
                array( 'point_text' => 'בקרת ספקים' ),
                array( 'point_text' => 'מדידת ביצועים שוטפת' ),
            ),
            'title_field' => '{{{ point_text }}}',
        ) );

        $this->end_controls_section();
    }

    protected function render() {
        $s = $this->get_settings_for_display();
        $badge = $s['badge_image']['url'] ?? '';
        $points = $s['points'] ?? array();

        echo '<div class="targo-iso-card">';

        if ( $badge ) {
            echo '<div class="targo-iso-badge"><img src="' . esc_url( $badge ) . '" alt="" /></div>';
        }

        echo '<div class="targo-iso-body">';
        if ( ! empty( $s['badge_label'] ) ) {
            echo '<div class="targo-iso-eyebrow">' . esc_html( $s['badge_label'] ) . '</div>';
        }
        $this->render_heading( 'h', $s, 'targo-iso-h' );
        if ( ! empty( $s['lead'] ) ) {
            echo '<p class="targo-iso-lead">' . esc_html( $s['lead'] ) . '</p>';
        }
        if ( ! empty( $points ) ) {
            echo '<ul class="targo-iso-points">';
            foreach ( $points as $p ) {
                echo '<li>' . esc_html( $p['point_text'] ) . '</li>';
            }
            echo '</ul>';
        }
        echo '</div>';

        echo '</div>';
    }
}
