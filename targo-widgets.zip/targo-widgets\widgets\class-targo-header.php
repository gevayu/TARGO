<?php
namespace Targo_Widgets;

if ( ! defined( 'ABSPATH' ) ) exit;

use Elementor\Controls_Manager;
use Elementor\Repeater;

/**
 * Sticky site header: logo (text or image) + nav menu + primary CTA.
 * Designed to be placed inside a Theme Builder Header template (Elementor Pro)
 * or directly into a page when Pro is unavailable.
 */
class Header extends Base_Widget {

    public function get_name() { return 'targo-header'; }
    public function get_title() { return __( 'Targo · Site Header', 'targo-widgets' ); }
    public function get_icon() { return 'eicon-site-logo'; }
    public function get_keywords() { return array( 'targo', 'header', 'nav', 'menu' ); }

    protected function register_controls() {

        // ───── BRAND ─────
        $this->start_controls_section( 'brand', array(
            'label' => __( 'Brand', 'targo-widgets' ),
            'tab'   => Controls_Manager::TAB_CONTENT,
        ) );

        $this->add_control( 'brand_type', array(
            'label'   => 'Brand display',
            'type'    => Controls_Manager::SELECT,
            'options' => array(
                'text'  => 'Text',
                'image' => 'Image',
            ),
            'default' => 'text',
        ) );

        $this->add_control( 'brand_text_he', array(
            'label'     => 'Brand text (Hebrew)',
            'type'      => Controls_Manager::TEXT,
            'default'   => 'ע.ש. טרגו פתרונות בע״מ',
            'condition' => array( 'brand_type' => 'text' ),
        ) );

        $this->add_control( 'brand_text_en', array(
            'label'     => 'Brand text (English / kicker)',
            'type'      => Controls_Manager::TEXT,
            'default'   => '· Targo',
            'condition' => array( 'brand_type' => 'text' ),
        ) );

        $this->add_control( 'brand_image', array(
            'label'     => 'Logo image',
            'type'      => Controls_Manager::MEDIA,
            'default'   => array(),
            'condition' => array( 'brand_type' => 'image' ),
        ) );

        $this->add_control( 'brand_url', array(
            'label'   => 'Brand link',
            'type'    => Controls_Manager::URL,
            'default' => array( 'url' => '/' ),
        ) );

        $this->end_controls_section();

        // ───── NAV ─────
        $this->start_controls_section( 'nav', array(
            'label' => __( 'Navigation', 'targo-widgets' ),
            'tab'   => Controls_Manager::TAB_CONTENT,
        ) );

        $rep = new Repeater();
        $rep->add_control( 'item_text', array(
            'label'   => 'Label',
            'type'    => Controls_Manager::TEXT,
            'default' => 'קישור',
        ) );
        $rep->add_control( 'item_url', array(
            'label'   => 'URL',
            'type'    => Controls_Manager::URL,
            'default' => array( 'url' => '#' ),
        ) );

        $this->add_control( 'menu_items', array(
            'label'   => 'Menu items',
            'type'    => Controls_Manager::REPEATER,
            'fields'  => $rep->get_controls(),
            'default' => array(
                array( 'item_text' => 'עמוד ראשי', 'item_url' => array( 'url' => '/' ) ),
                array( 'item_text' => 'אודות',      'item_url' => array( 'url' => '/about/' ) ),
            ),
            'title_field' => '{{{ item_text }}}',
        ) );

        $this->end_controls_section();

        // ───── CTA ─────
        $this->start_controls_section( 'cta', array(
            'label' => __( 'CTA button', 'targo-widgets' ),
            'tab'   => Controls_Manager::TAB_CONTENT,
        ) );

        $this->add_control( 'cta_text', array(
            'label'   => 'CTA text',
            'type'    => Controls_Manager::TEXT,
            'default' => 'דברו איתנו',
        ) );

        $this->add_control( 'cta_url', array(
            'label'   => 'CTA URL',
            'type'    => Controls_Manager::URL,
            'default' => array( 'url' => 'https://wa.link/huf1g6', 'is_external' => 'on' ),
        ) );

        $this->end_controls_section();

        // ───── STYLE ─────
        $this->start_controls_section( 'style_general', array(
            'label' => 'Header style',
            'tab'   => Controls_Manager::TAB_STYLE,
        ) );

        $this->add_control( 'header_bg', array(
            'label'     => 'Background',
            'type'      => Controls_Manager::COLOR,
            'default'   => 'rgba(255,255,255,0.92)',
            'selectors' => array(
                '{{WRAPPER}} .targo-header' => 'background: {{VALUE}};',
            ),
        ) );

        $this->add_control( 'sticky', array(
            'label'        => 'Sticky on scroll',
            'type'         => Controls_Manager::SWITCHER,
            'label_on'     => 'Yes',
            'label_off'    => 'No',
            'return_value' => 'yes',
            'default'      => 'yes',
        ) );

        $this->end_controls_section();

        // STYLE: brand
        $this->start_controls_section( 'style_brand', array(
            'label' => 'Brand text',
            'tab'   => Controls_Manager::TAB_STYLE,
        ) );
        $this->add_text_controls( 'brand_he', array(
            'label'         => 'Hebrew brand',
            'selector'      => '.targo-header-brand-he',
            'default_color' => '#0A083B',
        ) );
        $this->add_text_controls( 'brand_en', array(
            'label'         => 'English brand',
            'selector'      => '.targo-header-brand-en',
            'default_color' => '#a07c3a',
        ) );
        $this->end_controls_section();

        // STYLE: nav links
        $this->start_controls_section( 'style_nav', array(
            'label' => 'Nav links',
            'tab'   => Controls_Manager::TAB_STYLE,
        ) );
        $this->add_text_controls( 'nav', array(
            'label'         => 'Link',
            'selector'      => '.targo-header-link',
            'default_color' => '#0A083B',
        ) );
        $this->end_controls_section();
    }

    protected function render() {
        $s = $this->get_settings_for_display();

        $brand_url = ! empty( $s['brand_url']['url'] ) ? esc_url( $s['brand_url']['url'] ) : '/';
        $cta_url   = ! empty( $s['cta_url']['url'] )   ? esc_url( $s['cta_url']['url'] )   : '#';
        $sticky    = ! empty( $s['sticky'] ) && $s['sticky'] === 'yes';

        $cls = 'targo-header' . ( $sticky ? ' targo-header--sticky' : '' );
        echo '<header class="' . esc_attr( $cls ) . '">';
        echo '<div class="targo-header-inner">';

        // Brand
        echo '<a class="targo-header-brand" href="' . $brand_url . '">';
        if ( ( $s['brand_type'] ?? 'text' ) === 'image' && ! empty( $s['brand_image']['url'] ) ) {
            echo '<img src="' . esc_url( $s['brand_image']['url'] ) . '" alt="" />';
        } else {
            $he = esc_html( $s['brand_text_he'] ?? '' );
            $en = esc_html( $s['brand_text_en'] ?? '' );
            if ( $he ) echo '<span class="targo-header-brand-he">' . $he . '</span>';
            if ( $en ) echo '<span class="targo-header-brand-en">' . $en . '</span>';
        }
        echo '</a>';

        // Menu
        if ( ! empty( $s['menu_items'] ) ) {
            echo '<nav class="targo-header-nav" id="targo-header-nav" aria-label="ראשי">';
            echo '<ul>';
            foreach ( $s['menu_items'] as $it ) {
                $u = ! empty( $it['item_url']['url'] ) ? esc_url( $it['item_url']['url'] ) : '#';
                echo '<li><a class="targo-header-link" href="' . $u . '">' . esc_html( $it['item_text'] ) . '</a></li>';
            }
            echo '</ul>';
            echo '</nav>';
        }

        // CTA
        if ( ! empty( $s['cta_text'] ) ) {
            echo '<a class="targo-header-cta" href="' . $cta_url . '">' . esc_html( $s['cta_text'] ) . '</a>';
        }

        // Mobile hamburger toggle
        if ( ! empty( $s['menu_items'] ) ) {
            echo '<button class="targo-header-burger" type="button" aria-label="פתח תפריט" aria-expanded="false" aria-controls="targo-header-nav">';
            echo '<span></span><span></span><span></span>';
            echo '</button>';
        }

        echo '</div>';
        echo '</header>';
    }
}
