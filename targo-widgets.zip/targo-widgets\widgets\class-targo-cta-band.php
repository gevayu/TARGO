<?php
namespace Targo_Widgets;

if ( ! defined( 'ABSPATH' ) ) exit;

use Elementor\Controls_Manager;

/**
 * CTA band: dark surface with eyebrow + heading + lead + two buttons.
 * Used as the closing section on every page.
 */
class Cta_Band extends Base_Widget {

    public function get_name() { return 'targo-cta-band'; }
    public function get_title() { return __( 'Targo · CTA Band', 'targo-widgets' ); }
    public function get_icon() { return 'eicon-call-to-action'; }
    public function get_keywords() { return array( 'targo', 'cta', 'banner', 'call to action' ); }

    protected function register_controls() {

        $this->start_controls_section( 'content_section', array(
            'label' => __( 'Content', 'targo-widgets' ),
            'tab'   => Controls_Manager::TAB_CONTENT,
        ) );

        $this->add_control( 'eyebrow_text', array(
            'label'   => 'Eyebrow',
            'type'    => Controls_Manager::TEXT,
            'default' => 'מוכנים להתחיל?',
        ) );

        $this->add_heading_controls( 'h2', array(
            'label'         => 'Heading',
            'default_text'  => 'בואו נבנה <span class="hl">פתרון אמיתי</span>.',
            'default_tag'   => 'h2',
            'selector'      => '.targo-cta-h',
            'default_color' => '#FFFFFF',
        ) );

        $this->add_control( 'lead_text', array(
            'label'   => 'Lead',
            'type'    => Controls_Manager::TEXTAREA,
            'rows'    => 3,
            'default' => 'מתחילים בשיחה, ממשיכים לפרויקט. הראשון על חשבוננו אם לא הוכחנו ערך.',
        ) );

        $this->add_control( 'btn1_text', array(
            'label'   => 'Primary button',
            'type'    => Controls_Manager::TEXT,
            'default' => 'דברו איתנו ←',
        ) );
        $this->add_control( 'btn1_url', array(
            'label'   => 'Primary URL',
            'type'    => Controls_Manager::URL,
            'default' => array( 'url' => 'https://wa.link/huf1g6' ),
        ) );
        $this->add_control( 'btn2_text', array(
            'label'   => 'Secondary button',
            'type'    => Controls_Manager::TEXT,
            'default' => 'מה אנחנו עושים',
        ) );
        $this->add_control( 'btn2_url', array(
            'label'   => 'Secondary URL',
            'type'    => Controls_Manager::URL,
            'default' => array( 'url' => '#services' ),
        ) );

        $this->add_control( 'variant', array(
            'label'   => 'Variant',
            'type'    => Controls_Manager::SELECT,
            'options' => array(
                'full' => 'Full CTA band (large h2 + lead + buttons)',
                'diff' => 'Compact diff bar (single inline row)',
            ),
            'default' => 'full',
        ) );

        $this->add_control( 'check_note', array(
            'label'   => 'Check note (optional)',
            'type'    => Controls_Manager::TEXT,
            'default' => '✓ מגיבים תוך יום עסקים   ✓ ללא התחייבות',
            'description' => 'Small line beneath buttons.',
        ) );

        $this->end_controls_section();

        // STYLE: lead
        $this->start_controls_section( 'style_lead', array(
            'label' => 'Lead',
            'tab'   => Controls_Manager::TAB_STYLE,
        ) );
        $this->add_text_controls( 'cta_lead', array(
            'label'         => 'Lead',
            'selector'      => '.targo-cta-lead',
            'default_color' => '#FFFFFF',
        ) );
        $this->end_controls_section();
    }

    protected function render() {
        $s = $this->get_settings_for_display();

        $b1t = esc_html( $s['btn1_text'] ?? '' );
        $b1u = ! empty( $s['btn1_url']['url'] ) ? esc_url( $s['btn1_url']['url'] ) : '#';
        $b2t = esc_html( $s['btn2_text'] ?? '' );
        $b2u = ! empty( $s['btn2_url']['url'] ) ? esc_url( $s['btn2_url']['url'] ) : '#';

        $variant = $s['variant'] ?? 'full';
        $cls = $variant === 'diff' ? 'targo-cta-band--diff' : 'targo-cta-band';
        echo '<section class="' . esc_attr( $cls ) . '">';
        echo '<div class="targo-cta-inner">';
        if ( ! empty( $s['eyebrow_text'] ) ) {
            echo '<div class="targo-cta-eyebrow">' . esc_html( $s['eyebrow_text'] ) . '</div>';
        }
        $this->render_heading( 'h2', $s, 'targo-cta-h' );
        if ( ! empty( $s['lead_text'] ) ) {
            echo '<p class="targo-cta-lead">' . esc_html( $s['lead_text'] ) . '</p>';
        }
        echo '<div class="targo-cta-buttons">';
        if ( $b1t ) echo '<a class="targo-btn targo-btn-primary" href="' . $b1u . '">' . $b1t . '</a>';
        if ( $b2t ) echo '<a class="targo-btn targo-btn-ghost-light" href="' . $b2u . '">' . $b2t . '</a>';
        echo '</div>';
        if ( ! empty( $s['check_note'] ) ) {
            echo '<p class="targo-cta-check-note">' . esc_html( $s['check_note'] ) . '</p>';
        }
        echo '</div>';
        echo '</section>';
    }
}
