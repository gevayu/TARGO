<?php
namespace Targo_Widgets;

if ( ! defined( 'ABSPATH' ) ) exit;

use Elementor\Controls_Manager;

/**
 * Pull-quote with large opening glyph and attribution.
 */
class Pull_Quote extends Base_Widget {

    public function get_name() { return 'targo-pull-quote'; }
    public function get_title() { return __( 'Targo · Pull Quote', 'targo-widgets' ); }
    public function get_icon() { return 'eicon-blockquote'; }
    public function get_keywords() { return array( 'targo', 'quote', 'testimonial' ); }

    protected function register_controls() {

        $this->start_controls_section( 'content_section', array(
            'label' => __( 'Content', 'targo-widgets' ),
            'tab'   => Controls_Manager::TAB_CONTENT,
        ) );

        $this->add_heading_controls( 'quote', array(
            'label'         => 'Quote',
            'default_text'  => 'אנחנו לא מוכרים <span class="hl">שעות ייעוץ</span>. אנחנו מוכרים תוצאות.',
            'default_tag'   => 'p',
            'selector'      => '.targo-pull-quote-text',
            'default_color' => '#0A083B',
        ) );

        $this->add_control( 'attribution', array(
            'label'   => 'Attribution',
            'type'    => Controls_Manager::TEXT,
            'default' => 'ירון יוסף · מייסד טרגו',
        ) );

        $this->add_control( 'show_glyph', array(
            'label'        => 'Show opening glyph',
            'type'         => Controls_Manager::SWITCHER,
            'label_on'     => 'Yes',
            'label_off'    => 'No',
            'return_value' => 'yes',
            'default'      => 'yes',
        ) );

        $this->add_control( 'glyph_char', array(
            'label'   => 'Glyph character',
            'type'    => Controls_Manager::TEXT,
            'default' => '״',
            'condition' => array( 'show_glyph' => 'yes' ),
        ) );

        $this->end_controls_section();

        // STYLE: attribution
        $this->start_controls_section( 'style_attribution', array(
            'label' => 'Attribution',
            'tab'   => Controls_Manager::TAB_STYLE,
        ) );
        $this->add_text_controls( 'attribution', array(
            'label'         => 'Attribution',
            'selector'      => '.targo-pull-attribution',
            'default_color' => '#081F49',
        ) );
        $this->end_controls_section();
    }

    protected function render() {
        $s = $this->get_settings_for_display();
        $glyph = ! empty( $s['show_glyph'] ) && $s['show_glyph'] === 'yes';

        echo '<blockquote class="targo-pull-quote">';
        if ( $glyph ) {
            echo '<span class="targo-pull-glyph" aria-hidden="true">' . esc_html( $s['glyph_char'] ?? '״' ) . '</span>';
        }
        $this->render_heading( 'quote', $s, 'targo-pull-quote-text' );
        if ( ! empty( $s['attribution'] ) ) {
            echo '<cite class="targo-pull-attribution">' . esc_html( $s['attribution'] ) . '</cite>';
        }
        echo '</blockquote>';
    }
}
