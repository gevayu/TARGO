<?php
namespace Targo_Widgets;

if ( ! defined( 'ABSPATH' ) ) exit;

use Elementor\Controls_Manager;
use Elementor\Repeater;

/**
 * Site footer: 4-column layout (brand, contact, nav, legal) + bottom bar.
 */
class Footer extends Base_Widget {

    public function get_name() { return 'targo-footer'; }
    public function get_title() { return __( 'Targo · Site Footer', 'targo-widgets' ); }
    public function get_icon() { return 'eicon-footer'; }
    public function get_keywords() { return array( 'targo', 'footer' ); }

    protected function register_controls() {

        // ───── BRAND COLUMN ─────
        $this->start_controls_section( 'brand_col', array(
            'label' => __( 'Brand column', 'targo-widgets' ),
            'tab'   => Controls_Manager::TAB_CONTENT,
        ) );

        $this->add_heading_controls( 'brand_h', array(
            'label'         => 'Brand',
            'default_text'  => 'טרגו <span class="hl">פתרונות</span>',
            'default_tag'   => 'h3',
            'selector'      => '.targo-footer-brand-h',
            'default_color' => '#FFFFFF',
        ) );

        $this->add_control( 'brand_desc', array(
            'label'   => 'Brand description',
            'type'    => Controls_Manager::TEXTAREA,
            'rows'    => 4,
            'default' => 'תפעול, רכש, שרשרת אספקה ו-AI. ביצוע, לא ייעוץ — לתעשיית הביטחון, מד-טק, היטק והתעשייה.',
        ) );

        $this->end_controls_section();

        // ───── CONTACT COLUMN ─────
        $this->start_controls_section( 'contact_col', array(
            'label' => __( 'Contact column', 'targo-widgets' ),
            'tab'   => Controls_Manager::TAB_CONTENT,
        ) );

        $this->add_control( 'contact_title', array(
            'label'   => 'Column title',
            'type'    => Controls_Manager::TEXT,
            'default' => 'יצירת קשר',
        ) );

        $crep = new Repeater();
        $crep->add_control( 'c_label', array( 'label' => 'Label',  'type' => Controls_Manager::TEXT, 'default' => 'WhatsApp' ) );
        $crep->add_control( 'c_value', array( 'label' => 'Value',  'type' => Controls_Manager::TEXT, 'default' => '+972-50-000-0000' ) );
        $crep->add_control( 'c_url',   array( 'label' => 'URL',    'type' => Controls_Manager::URL,  'default' => array( 'url' => 'https://wa.link/huf1g6' ) ) );

        $this->add_control( 'contact_items', array(
            'label'   => 'Items',
            'type'    => Controls_Manager::REPEATER,
            'fields'  => $crep->get_controls(),
            'default' => array(
                array( 'c_label' => 'WhatsApp', 'c_value' => 'דברו איתנו עכשיו', 'c_url' => array( 'url' => 'https://wa.link/huf1g6' ) ),
                array( 'c_label' => 'אימייל',    'c_value' => 'info@targosolutions.com', 'c_url' => array( 'url' => 'mailto:info@targosolutions.com' ) ),
                array( 'c_label' => 'מיקום',     'c_value' => 'ישראל · פעילות גלובלית',   'c_url' => array( 'url' => '' ) ),
            ),
            'title_field' => '{{{ c_label }}}: {{{ c_value }}}',
        ) );

        $this->end_controls_section();

        // ───── NAV COLUMN ─────
        $this->start_controls_section( 'nav_col', array(
            'label' => __( 'Nav column', 'targo-widgets' ),
            'tab'   => Controls_Manager::TAB_CONTENT,
        ) );

        $this->add_control( 'nav_title', array(
            'label'   => 'Column title',
            'type'    => Controls_Manager::TEXT,
            'default' => 'באתר',
        ) );

        $nrep = new Repeater();
        $nrep->add_control( 'n_text', array( 'label' => 'Label', 'type' => Controls_Manager::TEXT, 'default' => 'קישור' ) );
        $nrep->add_control( 'n_url',  array( 'label' => 'URL',   'type' => Controls_Manager::URL,  'default' => array( 'url' => '#' ) ) );

        $this->add_control( 'nav_items', array(
            'label'   => 'Items',
            'type'    => Controls_Manager::REPEATER,
            'fields'  => $nrep->get_controls(),
            'default' => array(
                array( 'n_text' => 'בית',       'n_url' => array( 'url' => '/' ) ),
                array( 'n_text' => 'מי אנחנו',  'n_url' => array( 'url' => '/about/' ) ),
                array( 'n_text' => 'תעשיות',     'n_url' => array( 'url' => '/#industries' ) ),
                array( 'n_text' => 'מה עושים',   'n_url' => array( 'url' => '/#services' ) ),
            ),
            'title_field' => '{{{ n_text }}}',
        ) );

        $this->end_controls_section();

        // ───── LEGAL COLUMN ─────
        $this->start_controls_section( 'legal_col', array(
            'label' => __( 'Legal column', 'targo-widgets' ),
            'tab'   => Controls_Manager::TAB_CONTENT,
        ) );

        $this->add_control( 'legal_title', array(
            'label'   => 'Column title',
            'type'    => Controls_Manager::TEXT,
            'default' => 'משפטי',
        ) );

        $lrep = new Repeater();
        $lrep->add_control( 'l_text', array( 'label' => 'Label', 'type' => Controls_Manager::TEXT, 'default' => 'תקנון' ) );
        $lrep->add_control( 'l_url',  array( 'label' => 'URL',   'type' => Controls_Manager::URL,  'default' => array( 'url' => '#' ) ) );

        $this->add_control( 'legal_items', array(
            'label'   => 'Items',
            'type'    => Controls_Manager::REPEATER,
            'fields'  => $lrep->get_controls(),
            'default' => array(
                array( 'l_text' => 'תקנון ותנאי שימוש', 'l_url' => array( 'url' => '/tou/' ) ),
                array( 'l_text' => 'תקנון פרטיות',      'l_url' => array( 'url' => '/privacy-policy/' ) ),
                array( 'l_text' => 'הצהרת נגישות',      'l_url' => array( 'url' => '/accessibility/' ) ),
            ),
            'title_field' => '{{{ l_text }}}',
        ) );

        $this->end_controls_section();

        // ───── BOTTOM BAR ─────
        $this->start_controls_section( 'bottom', array(
            'label' => __( 'Bottom bar', 'targo-widgets' ),
            'tab'   => Controls_Manager::TAB_CONTENT,
        ) );

        $this->add_control( 'copy_text', array(
            'label'   => 'Copyright text',
            'type'    => Controls_Manager::TEXT,
            'default' => '© 2026 ע.ש. תרגו פתרונות בע״מ. כל הזכויות שמורות.',
        ) );

        $this->add_control( 'iso_text', array(
            'label'   => 'ISO badge text',
            'type'    => Controls_Manager::TEXT,
            'default' => 'מוסמכים ISO 9001',
        ) );

        $this->end_controls_section();

        // STYLE: column titles
        $this->start_controls_section( 'style_col_title', array(
            'label' => 'Column titles',
            'tab'   => Controls_Manager::TAB_STYLE,
        ) );
        $this->add_text_controls( 'col_title', array(
            'label'         => 'Column title',
            'selector'      => '.targo-footer-col-title',
            'default_color' => '#c9a55a',
        ) );
        $this->end_controls_section();

        // STYLE: links
        $this->start_controls_section( 'style_links', array(
            'label' => 'Links',
            'tab'   => Controls_Manager::TAB_STYLE,
        ) );
        $this->add_text_controls( 'link', array(
            'label'         => 'Link',
            'selector'      => '.targo-footer a',
            'default_color' => '#FFFFFF',
        ) );
        $this->end_controls_section();
    }

    protected function render() {
        $s = $this->get_settings_for_display();

        echo '<footer class="targo-footer">';
        echo '<div class="targo-footer-inner">';
        echo '<div class="targo-footer-grid">';

        // Brand
        echo '<div class="targo-footer-col targo-footer-col--brand">';
        $this->render_heading( 'brand_h', $s, 'targo-footer-brand-h' );
        if ( ! empty( $s['brand_desc'] ) ) {
            echo '<p class="targo-footer-brand-desc">' . esc_html( $s['brand_desc'] ) . '</p>';
        }
        echo '</div>';

        // Contact
        echo '<div class="targo-footer-col">';
        echo '<div class="targo-footer-col-title">' . esc_html( $s['contact_title'] ?? '' ) . '</div>';
        if ( ! empty( $s['contact_items'] ) ) {
            echo '<ul class="targo-footer-list">';
            foreach ( $s['contact_items'] as $it ) {
                $u = ! empty( $it['c_url']['url'] ) ? esc_url( $it['c_url']['url'] ) : '';
                echo '<li>';
                echo '<span class="targo-footer-list-label">' . esc_html( $it['c_label'] ) . '</span>';
                if ( $u ) {
                    echo '<a href="' . $u . '">' . esc_html( $it['c_value'] ) . '</a>';
                } else {
                    echo '<span>' . esc_html( $it['c_value'] ) . '</span>';
                }
                echo '</li>';
            }
            echo '</ul>';
        }
        echo '</div>';

        // Nav
        echo '<div class="targo-footer-col">';
        echo '<div class="targo-footer-col-title">' . esc_html( $s['nav_title'] ?? '' ) . '</div>';
        if ( ! empty( $s['nav_items'] ) ) {
            echo '<ul class="targo-footer-list">';
            foreach ( $s['nav_items'] as $it ) {
                $u = ! empty( $it['n_url']['url'] ) ? esc_url( $it['n_url']['url'] ) : '#';
                echo '<li><a href="' . $u . '">' . esc_html( $it['n_text'] ) . '</a></li>';
            }
            echo '</ul>';
        }
        echo '</div>';

        // Legal
        echo '<div class="targo-footer-col">';
        echo '<div class="targo-footer-col-title">' . esc_html( $s['legal_title'] ?? '' ) . '</div>';
        if ( ! empty( $s['legal_items'] ) ) {
            echo '<ul class="targo-footer-list">';
            foreach ( $s['legal_items'] as $it ) {
                $u = ! empty( $it['l_url']['url'] ) ? esc_url( $it['l_url']['url'] ) : '#';
                echo '<li><a href="' . $u . '">' . esc_html( $it['l_text'] ) . '</a></li>';
            }
            echo '</ul>';
        }
        echo '</div>';

        echo '</div>'; // grid

        // Bottom bar
        echo '<div class="targo-footer-bottom">';
        if ( ! empty( $s['copy_text'] ) ) {
            echo '<span class="targo-footer-copy">' . esc_html( $s['copy_text'] ) . '</span>';
        }
        if ( ! empty( $s['iso_text'] ) ) {
            echo '<span class="targo-footer-iso">' . esc_html( $s['iso_text'] ) . '</span>';
        }
        echo '</div>';

        echo '</div>';
        echo '</footer>';
    }
}
