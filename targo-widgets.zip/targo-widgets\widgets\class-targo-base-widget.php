<?php
namespace Targo_Widgets;

if ( ! defined( 'ABSPATH' ) ) exit;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Repeater;

/**
 * Shared base for all Targo widgets.
 * Provides helpers to add a heading-with-typography control bundle.
 */
abstract class Base_Widget extends Widget_Base {

    public function get_categories() {
        return array( 'targo' );
    }

    public function get_icon() {
        return 'eicon-text';
    }

    /**
     * Adds a complete "heading control bundle":
     *  - Text field (the heading text — supports HTML span.hl)
     *  - Heading tag (H1/H2/H3/H4/div)
     *  - Color
     *  - Typography (full group: family, weight, size, line-height, letter-spacing)
     *
     * Typography selectors target ".targo-{prefix}" inside the widget.
     */
    protected function add_heading_controls( $prefix, $args = array() ) {
        $defaults = array(
            'label'         => 'Heading',
            'default_text'  => 'Heading text',
            'default_tag'   => 'h2',
            'default_color' => '#0A0A0A',
            'selector'      => '.targo-' . $prefix,
        );
        $args = array_merge( $defaults, $args );

        $this->add_control(
            $prefix . '_text',
            array(
                'label'   => $args['label'] . ' — Text',
                'type'    => Controls_Manager::TEXTAREA,
                'rows'    => 2,
                'default' => $args['default_text'],
                'description' => 'Use <span class="hl">word</span> to color a word in the brand accent.',
                'dynamic' => array( 'active' => true ),
            )
        );

        $this->add_control(
            $prefix . '_tag',
            array(
                'label'   => $args['label'] . ' — Tag',
                'type'    => Controls_Manager::SELECT,
                'default' => $args['default_tag'],
                'options' => array(
                    'h1'  => 'H1',
                    'h2'  => 'H2',
                    'h3'  => 'H3',
                    'h4'  => 'H4',
                    'h5'  => 'H5',
                    'h6'  => 'H6',
                    'div' => 'div',
                ),
            )
        );

        $this->add_control(
            $prefix . '_color',
            array(
                'label'     => $args['label'] . ' — Color',
                'type'      => Controls_Manager::COLOR,
                'default'   => $args['default_color'],
                'selectors' => array(
                    '{{WRAPPER}} ' . $args['selector'] => 'color: {{VALUE}};',
                ),
            )
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            array(
                'name'     => $prefix . '_typography',
                'label'    => $args['label'] . ' — Typography',
                'selector' => '{{WRAPPER}} ' . $args['selector'],
            )
        );
    }

    /**
     * Render a heading element using the values from add_heading_controls().
     *
     * @param string $prefix    The control prefix used in add_heading_controls.
     * @param array  $settings  $this->get_settings_for_display()
     * @param string $extra_class Additional CSS classes for the heading element.
     * @param bool   $allow_html  If true, output text raw (so <span class="hl"> works).
     */
    protected function render_heading( $prefix, $settings, $extra_class = '', $allow_html = true ) {
        $tag   = $settings[ $prefix . '_tag' ] ?? 'h2';
        $text  = $settings[ $prefix . '_text' ] ?? '';
        $class = trim( 'targo-' . $prefix . ' ' . $extra_class );

        $allowed_tags = array( 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'div' );
        if ( ! in_array( $tag, $allowed_tags, true ) ) $tag = 'h2';

        $output = $allow_html
            ? wp_kses( $text, array(
                'span'   => array( 'class' => array(), 'style' => array() ),
                'strong' => array(),
                'em'     => array(),
                'br'     => array(),
                'small'  => array(),
            ) )
            : esc_html( $text );

        printf(
            '<%1$s class="%2$s">%3$s</%1$s>',
            esc_attr( $tag ),
            esc_attr( $class ),
            $output
        );
    }

    /**
     * Convenience: add a text-color + typography pair for a non-heading text element.
     */
    protected function add_text_controls( $prefix, $args = array() ) {
        $defaults = array(
            'label'         => 'Text',
            'default_color' => '#4A4540',
            'selector'      => '.targo-' . $prefix,
        );
        $args = array_merge( $defaults, $args );

        $this->add_control(
            $prefix . '_color',
            array(
                'label'     => $args['label'] . ' — Color',
                'type'      => Controls_Manager::COLOR,
                'default'   => $args['default_color'],
                'selectors' => array(
                    '{{WRAPPER}} ' . $args['selector'] => 'color: {{VALUE}};',
                ),
            )
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            array(
                'name'     => $prefix . '_typography',
                'label'    => $args['label'] . ' — Typography',
                'selector' => '{{WRAPPER}} ' . $args['selector'],
            )
        );
    }
}
